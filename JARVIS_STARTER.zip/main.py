
import tkinter as tk
from tkinter import scrolledtext
import threading
import subprocess
import webbrowser
import datetime as dt
import json
import os
import re
import time
import math
from pathlib import Path
from urllib.request import Request, urlopen


# ============================================================
# OPTIONAL MODULES
# ============================================================

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:
    import sounddevice as sd
except ImportError:
    sd = None

try:
    import psutil
except ImportError:
    psutil = None


# ============================================================
# CONFIG
# ============================================================

APP_NAME = "JARVIS"

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen3:4b"

MEMORY_FILE = Path("jarvis_memory.json")
NOTES_FILE = Path("jarvis_notes.txt")


# ============================================================
# COLORS
# ============================================================

BG = "#03060b"
PANEL = "#07101a"
PANEL2 = "#0a1622"

CYAN = "#00eaff"
BLUE = "#008cff"
GREEN = "#00ff9d"
RED = "#ff405c"
YELLOW = "#ffd166"

WHITE = "#dffaff"
DIM = "#557080"


# ============================================================
# JARVIS ENGINE
# ============================================================

class JarvisEngine:

    def __init__(self, gui):

        self.gui = gui

        self.recognizer = (
            sr.Recognizer()
            if sr
            else None
        )

        self.tts = None

        if pyttsx3:

            try:

                self.tts = pyttsx3.init()

                self.tts.setProperty(
                    "rate",
                    175
                )

                self.tts.setProperty(
                    "volume",
                    1.0
                )

            except Exception:

                self.tts = None

        self.memory = self.load_memory()

    # --------------------------------------------------------
    # MEMORY
    # --------------------------------------------------------

    def load_memory(self):

        if MEMORY_FILE.exists():

            try:

                return json.loads(
                    MEMORY_FILE.read_text(
                        encoding="utf-8"
                    )
                )

            except Exception:

                pass

        return {
            "facts": []
        }

    def save_memory(self):

        try:

            MEMORY_FILE.write_text(
                json.dumps(
                    self.memory,
                    indent=2,
                    ensure_ascii=False
                ),
                encoding="utf-8"
            )

        except Exception:

            pass

    # --------------------------------------------------------
    # SPEAK
    # --------------------------------------------------------

    def speak(self, text):

        self.gui.set_status(
            "SPEAKING",
            GREEN
        )

        if self.tts:

            try:

                self.tts.say(text)
                self.tts.runAndWait()

            except Exception:

                pass

        self.gui.set_status(
            "ONLINE",
            CYAN
        )

    # --------------------------------------------------------
    # MICROPHONE
    # --------------------------------------------------------

    def listen(self):

        if not sr or not sd:

            self.gui.add_message(
                "SYSTEM",
                "Microphone unavailable. "
                "Use the text box."
            )

            return

        try:

            self.gui.set_status(
                "LISTENING",
                YELLOW
            )

            samplerate = 16000
            duration = 6

            self.gui.add_message(
                "SYSTEM",
                "Listening..."
            )

            recording = sd.rec(
                int(
                    duration *
                    samplerate
                ),
                samplerate=samplerate,
                channels=1,
                dtype="int16"
            )

            sd.wait()

            audio = sr.AudioData(
                recording.tobytes(),
                samplerate,
                2
            )

            text = (
                self.recognizer
                .recognize_google(audio)
            )

            self.gui.set_input(
                text
            )

            self.gui.set_status(
                "ONLINE",
                CYAN
            )

            self.process(
                text
            )

        except sr.UnknownValueError:

            self.gui.add_message(
                "JARVIS",
                "I couldn't understand that."
            )

            self.gui.set_status(
                "ONLINE",
                CYAN
            )

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                f"Microphone error: {e}"
            )

            self.gui.set_status(
                "ONLINE",
                CYAN
            )

    # --------------------------------------------------------
    # OLLAMA
    # --------------------------------------------------------

    def ask_ai(self, question):

        self.gui.set_status(
            "THINKING",
            BLUE
        )

        facts = self.memory.get(
            "facts",
            []
        )

        memory = ""

        if facts:

            memory = (
                "\nUser memory:\n"
                +
                "\n".join(
                    "- " + x
                    for x in facts[-10:]
                )
            )

        prompt = f"""
You are JARVIS, a futuristic desktop AI assistant.

Be intelligent, helpful and concise.
Use natural language.
Keep spoken answers reasonably short.

{memory}

USER:
{question}

JARVIS:
"""

        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        }

        try:

            data = json.dumps(
                payload
            ).encode(
                "utf-8"
            )

            request = Request(
                OLLAMA_URL,
                data=data,
                headers={
                    "Content-Type":
                    "application/json"
                }
            )

            with urlopen(
                request,
                timeout=120
            ) as response:

                result = json.loads(
                    response.read()
                    .decode("utf-8")
                )

            answer = result.get(
                "response",
                "I couldn't generate a response."
            )

            answer = re.sub(
                r"<think>.*?</think>",
                "",
                answer,
                flags=re.DOTALL
            ).strip()

            self.gui.add_message(
                "JARVIS",
                answer
            )

            threading.Thread(
                target=self.speak,
                args=(answer,),
                daemon=True
            ).start()

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                "Ollama connection failed."
            )

            self.gui.add_message(
                "SYSTEM",
                str(e)
            )

            self.gui.set_status(
                "OFFLINE",
                RED
            )

    # --------------------------------------------------------
    # COMMANDS
    # --------------------------------------------------------

    def process(self, command):

        command = command.strip()

        if not command:
            return

        self.gui.add_message(
            "YOU",
            command
        )

        c = command.lower()

        # EXIT
        if c in {
            "exit",
            "quit",
            "shutdown jarvis",
            "goodbye"
        }:

            self.gui.add_message(
                "JARVIS",
                "Shutting down. Goodbye."
            )

            threading.Thread(
                target=self.speak,
                args=(
                    "Shutting down. Goodbye.",
                ),
                daemon=True
            ).start()

            self.gui.after(
                1500,
                self.gui.destroy
            )

            return

        # TIME
        if c in {
            "time",
            "what time is it",
            "tell me the time"
        }:

            answer = dt.datetime.now().strftime(
                "It is %I:%M %p."
            )

            self.gui.add_message(
                "JARVIS",
                answer
            )

            threading.Thread(
                target=self.speak,
                args=(answer,),
                daemon=True
            ).start()

            return

        # DATE
        if c in {
            "date",
            "what is today's date",
            "tell me the date"
        }:

            answer = dt.datetime.now().strftime(
                "Today is %A, %d %B %Y."
            )

            self.gui.add_message(
                "JARVIS",
                answer
            )

            threading.Thread(
                target=self.speak,
                args=(answer,),
                daemon=True
            ).start()

            return

        # OPEN
        if c.startswith("open "):

            target = command[
                5:
            ].strip().lower()

            sites = {

                "youtube":
                    "https://www.youtube.com",

                "google":
                    "https://www.google.com",

                "chatgpt":
                    "https://chatgpt.com",

                "gmail":
                    "https://mail.google.com",

                "github":
                    "https://github.com"

            }

            apps = {

                "notepad":
                    ["notepad.exe"],

                "calculator":
                    ["calc.exe"],

                "paint":
                    ["mspaint.exe"],

                "file explorer":
                    ["explorer.exe"]

            }

            if target in sites:

                webbrowser.open(
                    sites[target]
                )

                answer = (
                    f"Opening {target}."
                )

                self.gui.add_message(
                    "JARVIS",
                    answer
                )

                threading.Thread(
                    target=self.speak,
                    args=(answer,),
                    daemon=True
                ).start()

                return

            if target in apps:

                try:

                    subprocess.Popen(
                        apps[target]
                    )

                    answer = (
                        f"Opening {target}."
                    )

                    self.gui.add_message(
                        "JARVIS",
                        answer
                    )

                    threading.Thread(
                        target=self.speak,
                        args=(answer,),
                        daemon=True
                    ).start()

                except Exception as e:

                    self.gui.add_message(
                        "SYSTEM",
                        str(e)
                    )

                return

        # SEARCH
        if c.startswith("search "):

            query = command[
                7:
            ].strip()

            if query:

                url = (
                    "https://www.google.com/search?q="
                    +
                    query.replace(
                        " ",
                        "+"
                    )
                )

                webbrowser.open(
                    url
                )

                answer = (
                    "Searching the web."
                )

                self.gui.add_message(
                    "JARVIS",
                    answer
                )

                threading.Thread(
                    target=self.speak,
                    args=(answer,),
                    daemon=True
                ).start()

            return

        # NOTE
        if c.startswith("note "):

            note = command[
                5:
            ].strip()

            if note:

                stamp = dt.datetime.now().strftime(
                    "%Y-%m-%d %H:%M"
                )

                with NOTES_FILE.open(
                    "a",
                    encoding="utf-8"
                ) as f:

                    f.write(
                        f"[{stamp}] {note}\n"
                    )

                answer = (
                    "Note saved."
                )

                self.gui.add_message(
                    "JARVIS",
                    answer
                )

                threading.Thread(
                    target=self.speak,
                    args=(answer,),
                    daemon=True
                ).start()

            return

        # REMEMBER
        if c.startswith(
            "remember that "
        ):

            fact = command[
                len("remember that "):
            ].strip()

            if fact:

                self.memory[
                    "facts"
                ].append(
                    fact
                )

                self.save_memory()

                answer = (
                    "I will remember that."
                )

                self.gui.add_message(
                    "JARVIS",
                    answer
                )

                threading.Thread(
                    target=self.speak,
                    args=(answer,),
                    daemon=True
                ).start()

            return

        # MEMORY
        if c in {
            "what do you remember",
            "show memory"
        }:

            facts = self.memory.get(
                "facts",
                []
            )

            if facts:

                answer = (
                    "I remember: "
                    +
                    "; ".join(
                        facts[-5:]
                    )
                )

            else:

                answer = (
                    "I don't have any "
                    "saved memories yet."
                )

            self.gui.add_message(
                "JARVIS",
                answer
            )

            threading.Thread(
                target=self.speak,
                args=(answer,),
                daemon=True
            ).start()

            return

        # HELP
        if c in {
            "help",
            "commands"
        }:

            answer = (
                "You can ask questions, "
                "open websites, search, "
                "take notes, remember facts, "
                "or control supported apps."
            )

            self.gui.add_message(
                "JARVIS",
                answer
            )

            threading.Thread(
                target=self.speak,
                args=(answer,),
                daemon=True
            ).start()

            return

        # AI
        threading.Thread(
            target=self.ask_ai,
            args=(command,),
            daemon=True
        ).start()


# ============================================================
# FUTURISTIC GUI
# ============================================================

class JarvisGUI(tk.Tk):

    def __init__(self):

        super().__init__()

        self.title(
            "J.A.R.V.I.S — Advanced Interface"
        )

        self.geometry(
            "1200x750"
        )

        self.minsize(
            950,
            650
        )

        self.configure(
            bg=BG
        )

        self.engine = JarvisEngine(
            self
        )

        self.build_ui()

        self.animate_core()

        self.update_clock()

        self.update_stats()

        self.add_message(
            "JARVIS",
            "JARVIS online. Systems ready."
        )

        self.add_message(
            "SYSTEM",
            f"LOCAL AI // {OLLAMA_MODEL}"
        )

    # --------------------------------------------------------
    # UI
    # --------------------------------------------------------

    def build_ui(self):

        # HEADER
        header = tk.Frame(
            self,
            bg=BG
        )

        header.pack(
            fill="x",
            padx=25,
            pady=(18, 5)
        )

        tk.Label(
            header,
            text="J.A.R.V.I.S",
            font=(
                "Segoe UI",
                28,
                "bold"
            ),
            fg=CYAN,
            bg=BG
        ).pack(
            side="left"
        )

        tk.Label(
            header,
            text="  // ADVANCED DESKTOP INTELLIGENCE",
            font=(
                "Consolas",
                9
            ),
            fg=DIM,
            bg=BG
        ).pack(
            side="left",
            pady=(10, 0)
        )

        self.clock = tk.Label(
            header,
            text="",
            font=(
                "Consolas",
                12
            ),
            fg=WHITE,
            bg=BG
        )

        self.clock.pack(
            side="right"
        )

        # MAIN
        main = tk.Frame(
            self,
            bg=BG
        )

        main.pack(
            fill="both",
            expand=True,
            padx=25,
            pady=15
        )

        # LEFT
        left = tk.Frame(
            main,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#123348"
        )

        left.pack(
            side="left",
            fill="both",
            padx=(0, 12)
        )

        left.config(
            width=380
        )

        left.pack_propagate(
            False
        )

        tk.Label(
            left,
            text="REACTOR CORE",
            font=(
                "Consolas",
                11,
                "bold"
            ),
            fg=DIM,
            bg=PANEL
        ).pack(
            pady=(20, 5)
        )

        self.canvas = tk.Canvas(
            left,
            width=330,
            height=330,
            bg=PANEL,
            highlightthickness=0
        )

        self.canvas.pack()

        self.status_label = tk.Label(
            left,
            text="● ONLINE",
            font=(
                "Consolas",
                15,
                "bold"
            ),
            fg=CYAN,
            bg=PANEL
        )

        self.status_label.pack(
            pady=5
        )

        # SYSTEM PANEL
        info = tk.Frame(
            left,
            bg=PANEL2
        )

        info.pack(
            fill="x",
            padx=25,
            pady=20
        )

        self.cpu_label = tk.Label(
            info,
            text="CPU  --",
            font=("Consolas", 10),
            fg=WHITE,
            bg=PANEL2,
            anchor="w"
        )

        self.cpu_label.pack(
            fill="x",
            padx=12,
            pady=4
        )

        self.ram_label = tk.Label(
            info,
            text="RAM  --",
            font=("Consolas", 10),
            fg=WHITE,
            bg=PANEL2,
            anchor="w"
        )

        self.ram_label.pack(
            fill="x",
            padx=12,
            pady=4
        )

        tk.Label(
            info,
            text=f"AI   {OLLAMA_MODEL}",
            font=("Consolas", 10),
            fg=GREEN,
            bg=PANEL2,
            anchor="w"
        ).pack(
            fill="x",
            padx=12,
            pady=4
        )

        # RIGHT
        right = tk.Frame(
            main,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground="#123348"
        )

        right.pack(
            side="right",
            fill="both",
            expand=True
        )

        top = tk.Frame(
            right,
            bg=PANEL2,
            height=45
        )

        top.pack(
            fill="x"
        )

        top.pack_propagate(
            False
        )

        tk.Label(
            top,
            text="◈ NEURAL LINK",
            font=(
                "Consolas",
                11,
                "bold"
            ),
            fg=CYAN,
            bg=PANEL2
        ).pack(
            side="left",
            padx=15,
            pady=12
        )

        # CHAT
        self.chat = scrolledtext.ScrolledText(
            right,
            bg="#04080e",
            fg=WHITE,
            insertbackground=CYAN,
            font=(
                "Consolas",
                10
            ),
            wrap="word",
            borderwidth=0,
            highlightthickness=0,
            padx=15,
            pady=15
        )

        self.chat.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        self.chat.config(
            state="disabled"
        )

        # INPUT
        input_frame = tk.Frame(
            right,
            bg=PANEL2
        )

        input_frame.pack(
            fill="x",
            padx=10,
            pady=(0, 10)
        )

        self.entry = tk.Entry(
            input_frame,
            bg="#04080e",
            fg=WHITE,
            insertbackground=CYAN,
            font=(
                "Consolas",
                11
            ),
            relief="flat"
        )

        self.entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=(10, 5),
            pady=10,
            ipady=9
        )

        self.entry.bind(
            "<Return>",
            self.send_text
        )

        tk.Button(
            input_frame,
            text="SEND",
            command=self.send_text,
            bg="#0b2330",
            fg=CYAN,
            activebackground="#123d4e",
            activeforeground=WHITE,
            font=(
                "Consolas",
                10,
                "bold"
            ),
            relief="flat",
            padx=18
        ).pack(
            side="right",
            padx=5
        )

        tk.Button(
            input_frame,
            text="🎙 LISTEN",
            command=self.start_listening,
            bg="#102b22",
            fg=GREEN,
            activebackground="#174d3b",
            activeforeground=WHITE,
            font=(
                "Consolas",
                10,
                "bold"
            ),
            relief="flat",
            padx=15
        ).pack(
            side="right",
            padx=5
        )

        # FOOTER
        footer = tk.Frame(
            self,
            bg=BG
        )

        footer.pack(
            fill="x",
            padx=25,
            pady=(0, 15)
        )

        tk.Label(
            footer,
            text="SYSTEM STATUS // LOCAL MODE // OLLAMA LINKED",
            font=("Consolas", 8),
            fg=DIM,
            bg=BG
        ).pack(
            side="left"
        )

        tk.Label(
            footer,
            text="JARVIS v2.1",
            font=("Consolas", 8),
            fg=DIM,
            bg=BG
        ).pack(
            side="right"
        )

    # --------------------------------------------------------
    # CHAT
    # --------------------------------------------------------

    def add_message(
        self,
        sender,
        message
    ):

        def update():

            self.chat.config(
                state="normal"
            )

            if sender == "YOU":

                self.chat.insert(
                    "end",
                    "YOU  > ",
                    "YOU"
                )

            elif sender == "JARVIS":

                self.chat.insert(
                    "end",
                    "JARVIS > ",
                    "JARVIS"
                )

            else:

                self.chat.insert(
                    "end",
                    "SYS  > ",
                    "SYSTEM"
                )

            self.chat.insert(
                "end",
                message + "\n\n"
            )

            self.chat.tag_config(
                "YOU",
                foreground=YELLOW,
                font=(
                    "Consolas",
                    10,
                    "bold"
                )
            )

            self.chat.tag_config(
                "JARVIS",
                foreground=CYAN,
                font=(
                    "Consolas",
                    10,
                    "bold"
                )
            )

            self.chat.tag_config(
                "SYSTEM",
                foreground=DIM,
                font=(
                    "Consolas",
                    9,
                    "bold"
                )
            )

            self.chat.see(
                "end"
            )

            self.chat.config(
                state="disabled"
            )

        self.after(
            0,
            update
        )

    # --------------------------------------------------------
    # INPUT
    # --------------------------------------------------------

    def send_text(
        self,
        event=None
    ):

        text = self.entry.get().strip()

        if not text:
            return

        self.entry.delete(
            0,
            "end"
        )

        threading.Thread(
            target=self.engine.process,
            args=(text,),
            daemon=True
        ).start()

    def set_input(
        self,
        text
    ):

        def update():

            self.entry.delete(
                0,
                "end"
            )

            self.entry.insert(
                0,
                text
            )

        self.after(
            0,
            update
        )

    # --------------------------------------------------------
    # LISTEN
    # --------------------------------------------------------

    def start_listening(self):

        threading.Thread(
            target=self.engine.listen,
            daemon=True
        ).start()

    # --------------------------------------------------------
    # STATUS
    # --------------------------------------------------------

    def set_status(
        self,
        status,
        color
    ):

        def update():

            self.status_label.config(
                text=f"● {status}",
                fg=color
            )

        self.after(
            0,
            update
        )

    # --------------------------------------------------------
    # CORE
    # --------------------------------------------------------

    def animate_core(self):

        self.canvas.delete(
            "all"
        )

        cx = 165
        cy = 165

        t = time.time()

        pulse = (
            math.sin(t * 3)
            * 8
        )

        # rings
        for i in range(5):

            r = (
                55
                + i * 17
                + pulse
            )

            self.canvas.create_oval(
                cx-r,
                cy-r,
                cx+r,
                cy+r,
                outline=CYAN,
                width=1
            )

        # rotating rays
        for i in range(16):

            angle = (
                t * 0.8
                + i * math.pi / 8
            )

            r1 = 65
            r2 = 115

            x1 = (
                cx
                + math.cos(angle)
                * r1
            )

            y1 = (
                cy
                + math.sin(angle)
                * r1
            )

            x2 = (
                cx
                + math.cos(angle)
                * r2
            )

            y2 = (
                cy
                + math.sin(angle)
                * r2
            )

            self.canvas.create_line(
                x1,
                y1,
                x2,
                y2,
                fill=BLUE,
                width=2
            )

        # core
        self.canvas.create_oval(
            cx-50,
            cy-50,
            cx+50,
            cy+50,
            fill="#071c28",
            outline=CYAN,
            width=3
        )

        self.canvas.create_oval(
            cx-32,
            cy-32,
            cx+32,
            cy+32,
            fill="#0a3443",
            outline=WHITE,
            width=2
        )

        self.canvas.create_oval(
            cx-12,
            cy-12,
            cx+12,
            cy+12,
            fill=CYAN,
            outline=WHITE,
            width=1
        )

        self.canvas.create_text(
            cx,
            305,
            text="J A R V I S",
            fill=DIM,
            font=(
                "Consolas",
                10,
                "bold"
            )
        )

        self.after(
            40,
            self.animate_core
        )

    # --------------------------------------------------------
    # CLOCK
    # --------------------------------------------------------

    def update_clock(self):

        now = dt.datetime.now()

        self.clock.config(
            text=now.strftime(
                "%d %B %Y   %H:%M:%S"
            )
        )

        self.after(
            1000,
            self.update_clock
        )

    # --------------------------------------------------------
    # CPU/RAM
    # --------------------------------------------------------

    def update_stats(self):

        if psutil:

            try:

                cpu = psutil.cpu_percent()

                ram = (
                    psutil.virtual_memory()
                    .percent
                )

                self.cpu_label.config(
                    text=f"CPU  {cpu:>5.1f}%"
                )

                self.ram_label.config(
                    text=f"RAM  {ram:>5.1f}%"
                )

            except Exception:

                pass

        self.after(
            1500,
            self.update_stats
        )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    app = JarvisGUI()

    app.mainloop()
