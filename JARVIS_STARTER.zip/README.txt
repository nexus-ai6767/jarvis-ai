JARVIS STARTER
================

Beginner edition of the JARVIS personal AI assistant.

Included:
- Voice input / speech recognition
- Text-to-speech
- Local Ollama AI connection
- Notes and memory
- Basic website/app commands
- Futuristic desktop HUD

SETUP
-----
1. Install Python 3.11+.
2. Install the packages required by the project.
3. Install Ollama separately and make sure your selected local model is available.
4. Run main.py.

NOTE
----
This is the beginner/source edition. Hardware, operating-system configuration,
Ollama models, and third-party services may require separate setup.
