@echo off
title JARVIS
cd /d "%~dp0"
py main.py
if errorlevel 1 (echo.& echo JARVIS exited with an error.& pause)
