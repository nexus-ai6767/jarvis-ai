JARVIS PC RELEASE
=================

This package contains the supplied JARVIS desktop Python application.

Features present in this release:
- Local Ollama AI using qwen2.5:1.5b
- Voice wake word and speech commands
- pyttsx3 voice output
- Local voice enrollment / verification
- Persistent memory and notes
- Windows application and website launching
- TV control through ADB
- MediaPipe + OpenCV hand gesture mouse control

INSTALL
-------
1. Install Python 3.11+ and Ollama.
2. Make sure Ollama is running and qwen2.5:1.5b is available.
3. Double-click install.bat.
4. Double-click start_jarvis.bat.

The voiceprint is a convenience speaker-matching feature, not strong biometric security.
TV control requires the TV ADB connection configured in main.py.
