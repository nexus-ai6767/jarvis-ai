@echo off
title JARVIS - Installer
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo Python was not found. Install Python 3.11+ and enable Add Python to PATH.& pause & exit /b 1)
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
if errorlevel 1 (echo Installation failed.& pause & exit /b 1)
echo Installation complete. Run start_jarvis.bat
pause
