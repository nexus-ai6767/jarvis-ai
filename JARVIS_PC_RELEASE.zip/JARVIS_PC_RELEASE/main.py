import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading
import subprocess
import webbrowser
import datetime as dt
import json
import re
import time
import math
import os
import difflib
from pathlib import Path
from urllib.request import Request, urlopen, urlretrieve

# ============================================================
# OPTIONAL MODULES
# ============================================================

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:
    import sounddevice as sd
except ImportError:
    sd = None

try:
    import numpy as np
except ImportError:
    np = None

try:
    import psutil
except ImportError:
    psutil = None

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import mediapipe as mp
except ImportError:
    mp = None

try:
    import pyautogui
except ImportError:
    pyautogui = None


# ============================================================
# CONFIG
# ============================================================

APP_NAME = "JARVIS"

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen2.5:1.5b"

BASE_DIR = Path(__file__).resolve().parent

MEMORY_FILE = BASE_DIR / "jarvis_memory.json"
NOTES_FILE = BASE_DIR / "jarvis_notes.txt"
VOICEPRINT_FILE = BASE_DIR / "jarvis_voiceprint.npz"

MIC_DEVICE = 1

WAKE_WORDS = [
    "jarvis",
    "hey jarvis",
    "hey jervis",
    "okay jarvis",
    "ok jarvis",
    "jervis"
]

SAMPLE_RATE = 16000

# Voice pipeline tuning.  Wake detection deliberately uses a longer,
# overlapping-friendly window because very short recordings can clip the
# first/last syllable of "Jarvis".
WAKE_CHUNK_SECONDS = 3.8
COMMAND_SECONDS = 7.0
VOICE_VERIFY_SECONDS = 2.0
WAKE_MIN_RMS = 140.0
WAKE_MATCH_RATIO = 0.64
WAKE_POLL_DELAY = 0.08

TV_IP = "192.168.1.102"
TV_PORT = "5555"

ADB_PATH = BASE_DIR / "platform-tools" / "adb.exe"


# ============================================================
# COLORS
# ============================================================

BG = "#03060b"
PANEL = "#07101a"
PANEL2 = "#0a1622"

CYAN = "#ff9d2e"
BLUE = "#ff6b00"
GREEN = "#ffd166"
RED = "#ff4f3b"
YELLOW = "#ffb84d"
WHITE = "#fff4df"
DIM = "#8a6a4a"


# ============================================================
# HELPER
# ============================================================

def cosine(a, b):
    if np is None:
        return 0.0

    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)

    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)

    if na < 1e-8 or nb < 1e-8:
        return 0.0

    return float(np.dot(a, b) / (na * nb))


# ============================================================
# JARVIS ENGINE
# ============================================================

class JarvisEngine:

    def __init__(self, gui):

        self.gui = gui

        self.recognizer = sr.Recognizer() if sr else None

        self.speak_lock = threading.Lock()

        self.running = True

        self.listening_for_wake = False
        self.processing_voice = False

        self.voiceprint = self.load_voiceprint()
        self.memory = self.load_memory()

        # Gesture state
        self.gesture_running = False
        self.camera = None

        self.last_gesture = None
        self.last_gesture_time = 0

        # Prevent repeated gesture actions
        self.gesture_cooldown = 0.8

        # Advanced voice pipeline state
        self.noise_floor = float(WAKE_MIN_RMS)
        self.last_speech_time = 0.0
        self.voice_engine = None
        self.voice_id = None
        self._init_voice_engine()

    # ========================================================
    # MEMORY
    # ========================================================

    def load_memory(self):

        if MEMORY_FILE.exists():

            try:
                return json.loads(
                    MEMORY_FILE.read_text(
                        encoding="utf-8"
                    )
                )

            except Exception:
                pass

        return {
            "facts": []
        }

    def save_memory(self):

        try:

            MEMORY_FILE.write_text(
                json.dumps(
                    self.memory,
                    indent=2,
                    ensure_ascii=False
                ),
                encoding="utf-8"
            )

        except Exception:
            pass

    # ========================================================
    # VOICEPRINT
    # ========================================================

    def load_voiceprint(self):

        if not VOICEPRINT_FILE.exists():
            return None

        if np is None:
            return None

        try:

            data = np.load(
                VOICEPRINT_FILE
            )

            return np.asarray(
                data["voiceprint"],
                dtype=np.float32
            )

        except Exception:
            return None

    # ========================================================
    # VOICE FEATURES
    # ========================================================

    def voice_features(self, audio):

        if np is None:
            return None

        try:

            x = np.frombuffer(
                audio.get_raw_data(),
                dtype=np.int16
            ).astype(np.float32)

        except Exception:
            return None

        if x.size < 1000:
            return None

        x /= 32768.0

        x -= np.mean(x)

        peak = np.max(np.abs(x))

        if peak < 0.01:
            return None

        x /= max(
            peak,
            1e-6
        )

        frame_len = int(
            0.025 * SAMPLE_RATE
        )

        hop = int(
            0.010 * SAMPLE_RATE
        )

        frames = []

        for i in range(
            0,
            max(
                1,
                len(x) - frame_len
            ),
            hop
        ):

            frame = x[
                i:i + frame_len
            ]

            if len(frame) < frame_len:
                break

            frame = (
                frame *
                np.hamming(frame_len)
            )

            spec = (
                np.abs(
                    np.fft.rfft(frame)
                ) + 1e-8
            )

            power = spec * spec

            edges = np.geomspace(
                20,
                SAMPLE_RATE / 2,
                33
            )

            freqs = np.fft.rfftfreq(
                frame_len,
                1 / SAMPLE_RATE
            )

            band = []

            for j in range(32):

                mask = (
                    (freqs >= edges[j]) &
                    (freqs < edges[j + 1])
                )

                if np.any(mask):

                    value = np.log(
                        np.mean(
                            power[mask]
                        ) + 1e-8
                    )

                else:

                    value = -18.0

                band.append(value)

            rms = np.sqrt(
                np.mean(frame * frame)
                + 1e-8
            )

            zcr = np.mean(
                np.abs(
                    np.diff(
                        np.signbit(frame)
                    )
                )
            )

            frames.append(
                np.r_[
                    band,
                    np.log(rms + 1e-8),
                    zcr
                ]
            )

        if not frames:
            return None

        f = np.asarray(
            frames,
            dtype=np.float32
        )

        feat = np.r_[
            np.mean(f, axis=0),
            np.std(f, axis=0)
        ]

        feat -= np.mean(feat)

        feat /= (
            np.std(feat) +
            1e-6
        )

        return feat.astype(
            np.float32
        )

    # ========================================================
    # VOICE ENROLLMENT
    # ========================================================

    def enroll_voice(self):

        if not sr or not sd or not np:

            self.gui.add_message(
                "SYSTEM",
                "Voice enrollment requires speech_recognition, sounddevice and numpy."
            )

            return

        if self.speak_lock.locked():
            return

        self.processing_voice = True

        try:

            self.gui.set_status(
                "ENROLLING",
                YELLOW
            )

            self.gui.add_message(
                "SYSTEM",
                "Voice enrollment started."
            )

            samples = []

            for i in range(3):

                self.gui.add_message(
                    "SYSTEM",
                    f"Sample {i + 1}/3: speak now..."
                )

                self.speak(
                    f"Sample {i + 1}. Please speak now."
                )

                audio = self.record_audio(
                    VOICE_VERIFY_SECONDS
                )

                feat = self.voice_features(
                    audio
                )

                if feat is not None:

                    samples.append(feat)

                else:

                    self.gui.add_message(
                        "SYSTEM",
                        "Sample was too quiet. Try again."
                    )

            if len(samples) < 2:

                self.gui.add_message(
                    "SYSTEM",
                    "Enrollment failed."
                )

                return

            vp = np.mean(
                np.stack(samples),
                axis=0
            )

            vp /= (
                np.linalg.norm(vp)
                + 1e-8
            )

            np.savez(
                VOICEPRINT_FILE,
                voiceprint=vp
            )

            self.voiceprint = vp

            self.gui.voice_auth_update()

            self.gui.add_message(
                "SYSTEM",
                "Voice enrolled successfully."
            )

            self.speak_async(
                "Voice enrollment complete."
            )

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                f"Enrollment error: {e}"
            )

        finally:

            self.processing_voice = False

            self.gui.set_status(
                "WAITING",
                CYAN
            )

    # ========================================================
    # VERIFY VOICE
    # ========================================================

    def verify_voice(self, audio):

        if self.voiceprint is None:
            return True, 1.0

        feat = self.voice_features(
            audio
        )

        if feat is None:
            return False, 0.0

        score = cosine(
            feat,
            self.voiceprint
        )

        return (
            score >= 0.72,
            score
        )

    # ========================================================
    # SPEAK
    # ========================================================

    def _init_voice_engine(self):
        """Initialize one persistent Windows TTS engine and choose a
        British male voice when the OS provides one.

        This does not imitate a real actor's voice; it selects the closest
        available system voice for a deep, cinematic British AI character.
        """
        if not pyttsx3:
            return
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", 158)
            engine.setProperty("volume", 1.0)

            voices = engine.getProperty("voices") or []
            preferred = (
                "george", "ryan", "daniel", "arthur", "oliver",
                "uk english", "english - united kingdom", "en-gb"
            )
            chosen = None
            for voice in voices:
                blob = " ".join([
                    str(getattr(voice, "id", "")),
                    str(getattr(voice, "name", "")),
                    str(getattr(voice, "languages", ""))
                ]).lower()
                if any(x in blob for x in preferred):
                    chosen = voice
                    break

            if chosen is None and voices:
                # Prefer an English voice over an arbitrary installed voice.
                for voice in voices:
                    blob = " ".join([
                        str(getattr(voice, "id", "")),
                        str(getattr(voice, "name", "")),
                        str(getattr(voice, "languages", ""))
                    ]).lower()
                    if "english" in blob or "en_" in blob or "en-" in blob:
                        chosen = voice
                        break

            if chosen is not None:
                engine.setProperty("voice", chosen.id)
                self.voice_id = chosen.id

            self.voice_engine = engine
        except Exception:
            self.voice_engine = None

    def speak(self, text):

        if not text:
            return

        with self.speak_lock:

            self.gui.set_status("SPEAKING", GREEN)

            if not pyttsx3:
                self.gui.add_message("SYSTEM", "pyttsx3 is not installed.")
                self.gui.set_status("ONLINE", CYAN)
                return

            try:
                if self.voice_engine is None:
                    self._init_voice_engine()

                engine = self.voice_engine
                if engine is None:
                    raise RuntimeError("TTS engine unavailable")

                # Small prosody changes make the system sound less robotic
                # while staying within the selected OS voice.
                engine.setProperty("rate", 158)
                engine.setProperty("volume", 1.0)
                engine.say(str(text))
                engine.runAndWait()

            except Exception as e:
                # Rebuild once if SAPI/pyttsx3 got stuck.
                try:
                    self.voice_engine = None
                    self._init_voice_engine()
                    if self.voice_engine is not None:
                        self.voice_engine.say(str(text))
                        self.voice_engine.runAndWait()
                except Exception:
                    self.gui.add_message("SYSTEM", f"Voice error: {e}")

            self.gui.set_status("WAITING", CYAN)

    def speak_async(self, text):

        threading.Thread(
            target=self.speak,
            args=(text,),
            daemon=True
        ).start()

    # ========================================================
    # MICROPHONE
    # ========================================================

    def record_audio(self, seconds):

        if not sd or not np or not sr:
            raise RuntimeError("Voice modules are unavailable.")

        recording = sd.rec(
            int(seconds * SAMPLE_RATE),
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="int16",
            device=MIC_DEVICE
        )
        sd.wait()
        return sr.AudioData(recording.tobytes(), SAMPLE_RATE, 2)

    def _capture_utterance(self, max_seconds=5.5, start_timeout=8.0,
                           silence_seconds=0.62, min_seconds=0.28):
        """Low-latency VAD capture with pre-roll.

        Instead of recording a fixed 3.8/7 second block, wait for actual
        speech, keep a small pre-roll so the first consonant is not clipped,
        and stop shortly after the speaker becomes silent. This is the main
        reason a single natural 'Jarvis ...' utterance is much easier to catch.
        """
        if not sd or not np or not sr:
            return None

        block = 320  # 20 ms at 16 kHz
        pre_blocks = 18  # ~360 ms
        chunks = []
        pre = []
        started = False
        speech_blocks = 0
        silent_blocks = 0
        elapsed = 0.0
        start_deadline = time.time() + start_timeout

        # Adaptive threshold. Keep it bounded so a quiet room still works.
        threshold = max(
            125.0,
            min(950.0, self.noise_floor * 2.35)
        )

        try:
            with sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=1,
                dtype="int16",
                blocksize=block,
                device=MIC_DEVICE
            ) as stream:
                while time.time() < start_deadline:
                    data, _ = stream.read(block)
                    arr = np.asarray(data[:, 0], dtype=np.int16).copy()
                    rms = float(np.sqrt(np.mean(arr.astype(np.float32) ** 2)))
                    elapsed += block / SAMPLE_RATE

                    if not started:
                        pre.append(arr)
                        if len(pre) > pre_blocks:
                            pre.pop(0)

                        # Continuously learn the quiet-room baseline.
                        if rms < threshold * 0.72:
                            self.noise_floor = (
                                self.noise_floor * 0.92 + rms * 0.08
                            )
                            threshold = max(
                                120.0,
                                min(950.0, self.noise_floor * 2.35)
                            )

                        if rms >= threshold:
                            started = True
                            chunks.extend(pre)
                            chunks.append(arr)
                            speech_blocks = 1
                            silent_blocks = 0
                            self.last_speech_time = time.time()
                            self.gui.set_status("LISTENING", YELLOW)
                        continue

                    chunks.append(arr)
                    speech_blocks += 1

                    if rms >= threshold * 0.72:
                        silent_blocks = 0
                        self.last_speech_time = time.time()
                    else:
                        silent_blocks += 1

                    duration = len(chunks) * block / SAMPLE_RATE
                    if (silent_blocks * block / SAMPLE_RATE >= silence_seconds
                            and duration >= min_seconds):
                        break
                    if duration >= max_seconds:
                        break

            if not started or not chunks:
                return None

            audio_np = np.concatenate(chunks).astype(np.int16)
            return sr.AudioData(audio_np.tobytes(), SAMPLE_RATE, 2)

        except Exception as e:
            self.gui.add_message("SYSTEM", f"Mic stream error: {e}")
            return None

    # ========================================================
    # SPEECH RECOGNITION
    # ========================================================

    def _audio_rms(self, audio):

        if np is None or audio is None:
            return 0.0

        try:
            raw = np.frombuffer(
                audio.get_raw_data(),
                dtype=np.int16
            ).astype(np.float32)

            if raw.size == 0:
                return 0.0

            return float(np.sqrt(np.mean(raw * raw)))

        except Exception:
            return 0.0

    def _clean_speech_text(self, text):

        text = (text or "").lower()
        text = re.sub(r"[^a-z0-9 ]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _wake_score(self, text):
        """Return a robust 0..1 wake-word score.

        Google occasionally returns variants such as "jarvis", "jarvis's",
        "jervis", or a longer sentence containing the wake word.  Exact
        substring matching alone is therefore too brittle.
        """

        clean = self._clean_speech_text(text)
        if not clean:
            return 0.0

        if any(word in clean for word in WAKE_WORDS):
            return 1.0

        tokens = clean.split()
        best = 0.0

        for token in tokens:
            # The important part of the wake word is the single token
            # "jarvis".  Compare against common transcription distortions.
            score = difflib.SequenceMatcher(
                None,
                token,
                "jarvis"
            ).ratio()
            best = max(best, score)

        # Also compare the whole phrase when ASR joins words oddly.
        best = max(
            best,
            difflib.SequenceMatcher(
                None,
                clean.replace(" ", ""),
                "jarvis"
            ).ratio()
        )

        return best

    def _extract_command_after_wake(self, text):

        clean = self._clean_speech_text(text)
        if not clean:
            return ""

        # If the user says "Jarvis open YouTube", don't make them wait for
        # a second listening cycle.  Return everything after the wake word.
        m = re.search(r"\b(?:hey |okay |ok |yo )?(?:jarvis|jervis)\b\s*(.*)$", clean)
        if m:
            return m.group(1).strip()

        # Fuzzy case: "jervis open youtube" etc.
        parts = clean.split()
        for i, token in enumerate(parts):
            score = difflib.SequenceMatcher(
                None,
                token,
                "jarvis"
            ).ratio()
            if score >= WAKE_MATCH_RATIO:
                return " ".join(parts[i + 1:]).strip()

        return ""

    def recognize_audio(self, audio, retries=2, prefer_wake=False):

        if not self.recognizer or audio is None:
            return ""

        last_error = None

        for attempt in range(max(1, retries)):
            try:
                # Ask Google for alternatives. A transcription such as
                # "Jervis" can lose to a less likely alternative, so for the
                # wake stage we explicitly rank alternatives by wake score.
                result = self.recognizer.recognize_google(
                    audio,
                    language="en-IN",
                    show_all=True
                )

                if not result:
                    return ""

                alternatives = result.get("alternative", []) if isinstance(result, dict) else []
                if not alternatives:
                    return ""

                candidates = [
                    str(x.get("transcript", "")).strip()
                    for x in alternatives
                    if isinstance(x, dict) and x.get("transcript")
                ]
                if not candidates:
                    return ""

                if prefer_wake:
                    candidates.sort(
                        key=lambda x: self._wake_score(x),
                        reverse=True
                    )
                else:
                    # Google confidence is useful when supplied.
                    alternatives_sorted = sorted(
                        alternatives,
                        key=lambda x: float(x.get("confidence", 0.0)),
                        reverse=True
                    )
                    candidates = [
                        str(x.get("transcript", "")).strip()
                        for x in alternatives_sorted
                        if x.get("transcript")
                    ] or candidates

                return candidates[0]

            except sr.UnknownValueError:
                return ""
            except sr.RequestError as e:
                last_error = e
                if attempt + 1 < retries:
                    time.sleep(0.25)
                    continue
            except Exception as e:
                last_error = e
                if attempt + 1 < retries:
                    time.sleep(0.15)
                    continue

        if isinstance(last_error, sr.RequestError):
            self.gui.add_message(
                "SYSTEM",
                f"Speech recognition network error: {last_error}"
            )
        return ""

    # ========================================================
    # WAKE WORD LISTENER

    # ========================================================

    def _wait_for_voice(self):
        return self._capture_utterance(
            max_seconds=5.5,
            start_timeout=8.0,
            silence_seconds=0.62,
            min_seconds=0.28
        )

    def _process_wake_audio(self, audio):

        if audio is None:
            return False

        text = self.recognize_audio(audio, retries=2, prefer_wake=True)
        if not text:
            return False

        self.gui.set_input(text)
        score = self._wake_score(text)
        if score < WAKE_MATCH_RATIO:
            return False

        if self.voiceprint is not None:
            ok, speaker_score = self.verify_voice(audio)
            self.gui.add_message("SYSTEM", f"Speaker score: {speaker_score:.2f}")
            if not ok:
                self.gui.add_message("SYSTEM", "Unknown voice. Ignoring wake word.")
                return False

        self.processing_voice = True
        self.gui.set_status("WAKE DETECTED", GREEN)
        self.gui.add_message("SYSTEM", f"Wake detected ({score:.2f}).")

        direct_command = self._extract_command_after_wake(text)
        if direct_command:
            self.gui.set_status("PROCESSING", YELLOW)
            self.process(direct_command)
            return True

        # If only "Jarvis" was spoken, respond and capture the next natural
        # utterance with the same VAD engine.
        self.speak("Yes?")
        self.gui.set_status("LISTENING", YELLOW)
        command_audio = self._capture_utterance(
            max_seconds=7.0,
            start_timeout=5.0,
            silence_seconds=0.68,
            min_seconds=0.28
        )

        if command_audio is None:
            self.speak("I didn't catch that.")
            return True

        if self.voiceprint is not None:
            ok, speaker_score = self.verify_voice(command_audio)
            self.gui.add_message("SYSTEM", f"Command voice score: {speaker_score:.2f}")
            if not ok:
                self.gui.add_message("SYSTEM", "Command rejected.")
                self.speak("Voice not recognized.")
                return True

        command = self.recognize_audio(command_audio, retries=2)
        if command:
            self.gui.set_input(command)
            self.process(command)
        else:
            self.speak("I didn't catch that.")
        return True

    def wake_listener(self):

        if not sr or not sd or not np:
            self.gui.add_message("SYSTEM", "Voice system unavailable.")
            return

        self.listening_for_wake = True
        self.gui.add_message(
            "SYSTEM",
            "Advanced VAD wake listener active. Say 'Jarvis' naturally."
        )
        self.gui.set_status("WAITING", CYAN)

        while self.running:
            try:
                if self.speak_lock.locked() or self.processing_voice:
                    time.sleep(0.06)
                    continue

                audio = self._wait_for_voice()
                if audio is None:
                    continue

                self._process_wake_audio(audio)
                self.processing_voice = False
                self.gui.set_status("WAITING", CYAN)
                time.sleep(0.05)

            except Exception as e:
                self.processing_voice = False
                self.gui.add_message("SYSTEM", f"Wake listener error: {e}")
                self.gui.set_status("WAITING", CYAN)
                time.sleep(0.35)

    # ========================================================
    # MANUAL LISTEN
    # ========================================================

    def listen_once(self):

        if self.processing_voice:
            return

        self.processing_voice = True

        try:

            self.gui.set_status(
                "LISTENING",
                YELLOW
            )

            audio = self._capture_utterance(
                max_seconds=7.0,
                start_timeout=6.0,
                silence_seconds=0.68,
                min_seconds=0.28
            )

            if audio is None:
                self.speak("I didn't hear anything.")
                return

            text = self.recognize_audio(
                audio
            )

            if text:

                if self.voiceprint is not None:

                    ok, score = (
                        self.verify_voice(
                            audio
                        )
                    )

                    if not ok:

                        self.gui.add_message(
                            "SYSTEM",
                            f"Voice not recognized ({score:.2f})."
                        )

                        return

                self.process(
                    text
                )

            else:

                self.speak(
                    "I couldn't understand that."
                )

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                f"Microphone error: {e}"
            )

        finally:

            self.processing_voice = False

            self.gui.set_status(
                "WAITING",
                CYAN
            )

    # ========================================================
    # ADB
    # ========================================================

    def adb_raw(self, serial, *args):

        if not ADB_PATH.exists():

            self.gui.add_message(
                "SYSTEM",
                f"ADB not found: {ADB_PATH}"
            )

            return False

        try:

            result = subprocess.run(
                [
                    str(ADB_PATH),
                    "-s",
                    serial,
                    *args
                ],
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode == 0:
                return True

            self.gui.add_message(
                "SYSTEM",
                result.stderr.strip()
                or result.stdout.strip()
                or "ADB command failed."
            )

            return False

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                f"ADB error: {e}"
            )

            return False

    def adb_devices(self):

        if not ADB_PATH.exists():
            return []

        try:

            result = subprocess.run(
                [
                    str(ADB_PATH),
                    "devices"
                ],
                capture_output=True,
                text=True,
                timeout=4
            )

            devices = []

            for line in result.stdout.splitlines():

                parts = (
                    line.strip()
                    .split()
                )

                if (
                    len(parts) >= 2
                    and parts[1] == "device"
                ):

                    devices.append(
                        parts[0]
                    )

            return devices

        except Exception:
            return []

    def adb(self, *args):

        tv = (
            f"{TV_IP}:{TV_PORT}"
        )

        if tv not in self.adb_devices():

            try:

                result = subprocess.run(
                    [
                        str(ADB_PATH),
                        "connect",
                        tv
                    ],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                if tv not in self.adb_devices():

                    self.gui.add_message(
                        "SYSTEM",
                        "TV ADB unavailable."
                    )

                    return False

            except Exception as e:

                self.gui.add_message(
                    "SYSTEM",
                    f"ADB connection error: {e}"
                )

                return False

        return self.adb_raw(
            tv,
            *args
        )

    # ========================================================
    # TV CONTROL
    # ========================================================

    def tv_command(self, command):

        c = command.lower().strip()

        if any(
            x in c
            for x in [
                "volume up",
                "increase volume",
                "raise volume",
                "sound up"
            ]
        ):

            return self._tv_key(
                "24",
                "Volume increased."
            )

        if any(
            x in c
            for x in [
                "volume down",
                "decrease volume",
                "lower volume",
                "sound down"
            ]
        ):

            return self._tv_key(
                "25",
                "Volume decreased."
            )

        if c in {
            "mute",
            "mute tv",
            "mute the tv"
        }:

            return self._tv_key(
                "164",
                "TV muted."
            )

        if c in {
            "home",
            "tv home",
            "home screen"
        }:

            return self._tv_key(
                "3",
                "Opening TV home."
            )

        if c in {
            "back",
            "tv back",
            "go back on tv"
        }:

            return self._tv_key(
                "4",
                "Going back."
            )

        if c in {
            "tv up",
            "up on tv"
        }:

            return self._tv_key(
                "19",
                None
            )

        if c in {
            "tv down",
            "down on tv"
        }:

            return self._tv_key(
                "20",
                None
            )

        if c in {
            "tv left",
            "left on tv"
        }:

            return self._tv_key(
                "21",
                None
            )

        if c in {
            "tv right",
            "right on tv"
        }:

            return self._tv_key(
                "22",
                None
            )

        if any(
            x in c
            for x in [
                "pause tv",
                "pause video",
                "play tv",
                "play video",
                "play pause"
            ]
        ):

            return self._tv_key(
                "85",
                "Play pause."
            )

        if any(
            x in c
            for x in [
                "channel up",
                "next channel"
            ]
        ):

            return self._tv_key(
                "166",
                "Next channel."
            )

        if any(
            x in c
            for x in [
                "channel down",
                "previous channel"
            ]
        ):

            return self._tv_key(
                "167",
                "Previous channel."
            )

        if any(
            x in c
            for x in [
                "turn off tv",
                "switch off tv",
                "power off tv"
            ]
        ):

            return self._tv_key(
                "26",
                "Turning the TV off."
            )

        return False

    def _tv_key(
        self,
        key,
        response
    ):

        ok = self.adb(
            "shell",
            "input",
            "keyevent",
            key
        )

        if ok and response:
            self.speak_async(
                response
            )

        return True

    # ========================================================
    # OLLAMA AI
    # ========================================================

    def ask_ai(self, question):

        self.gui.set_status(
            "THINKING",
            BLUE
        )

        facts = self.memory.get(
            "facts",
            []
        )

        memory = ""

        if facts:

            memory = (
                "\nUser memory:\n"
                +
                "\n".join(
                    "- " + x
                    for x in facts[-10:]
                )
            )

        prompt = f"""
You are JARVIS, a futuristic desktop AI assistant.

Be intelligent, helpful and concise.
Keep spoken answers reasonably short.
Do not use unnecessary markdown.

{memory}

USER:
{question}

JARVIS:
"""

        try:

            data = json.dumps(
                {
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False
                }
            ).encode(
                "utf-8"
            )

            req = Request(
                OLLAMA_URL,
                data=data,
                headers={
                    "Content-Type":
                    "application/json"
                }
            )

            with urlopen(
                req,
                timeout=120
            ) as response:

                result = json.loads(
                    response
                    .read()
                    .decode("utf-8")
                )

            answer = re.sub(
                r"<think>.*?</think>",
                "",
                result.get(
                    "response",
                    ""
                ),
                flags=re.DOTALL
            ).strip()

            if not answer:
                answer = (
                    "I couldn't generate a response."
                )

            self.gui.add_message(
                "JARVIS",
                answer
            )

            self.speak(
                answer
            )

        except Exception as e:

            self.gui.add_message(
                "SYSTEM",
                "Ollama connection failed."
            )

            self.gui.add_message(
                "SYSTEM",
                str(e)
            )

            self.gui.set_status(
                "OFFLINE",
                RED
            )

    # ========================================================
    # RESPONSE
    # ========================================================

    def respond(self, answer):

        self.gui.add_message(
            "JARVIS",
            answer
        )

        self.speak(
            answer
        )

    # ========================================================
    # COMMAND PROCESSOR
    # ========================================================

    def process(self, command):

        command = command.strip()

        if not command:
            return

        self.gui.add_message(
            "YOU",
            command
        )

        c = command.lower()

        # TV
        if self.tv_command(command):
            return

        # EXIT
        if c in {
            "exit",
            "quit",
            "shutdown jarvis",
            "goodbye",
            "close jarvis"
        }:

            self.respond(
                "Shutting down. Goodbye."
            )

            self.running = False

            self.gui.after(
                1800,
                self.gui.destroy
            )

            return

        # TIME
        if c in {
            "time",
            "what time is it",
            "tell me the time"
        }:

            self.respond(
                dt.datetime.now().strftime(
                    "It is %I:%M %p."
                )
            )

            return

        # DATE
        if c in {
            "date",
            "what is today's date",
            "tell me the date",
            "today's date"
        }:

            self.respond(
                dt.datetime.now().strftime(
                    "Today is %A, %d %B %Y."
                )
            )

            return

        # OPEN
        if c.startswith("open "):

            target = (
                command[5:]
                .strip()
                .lower()
            )

            sites = {
                "youtube":
                    "https://www.youtube.com",

                "google":
                    "https://www.google.com",

                "chatgpt":
                    "https://chatgpt.com",

                "gmail":
                    "https://mail.google.com",

                "github":
                    "https://github.com"
            }

            apps = {
                "notepad":
                    ["notepad.exe"],

                "calculator":
                    ["calc.exe"],

                "paint":
                    ["mspaint.exe"],

                "file explorer":
                    ["explorer.exe"]
            }

            if target in sites:

                webbrowser.open(
                    sites[target]
                )

                self.respond(
                    f"Opening {target}."
                )

                return

            if target in apps:

                try:

                    subprocess.Popen(
                        apps[target]
                    )

                    self.respond(
                        f"Opening {target}."
                    )

                except Exception as e:

                    self.gui.add_message(
                        "SYSTEM",
                        str(e)
                    )

                return

        # SEARCH
        if c.startswith("search "):

            query = (
                command[7:]
                .strip()
            )

            if query:

                webbrowser.open(
                    "https://www.google.com/search?q="
                    +
                    query.replace(
                        " ",
                        "+"
                    )
                )

                self.respond(
                    "Searching the web."
                )

            return

        # NOTE
        if c.startswith("note "):

            note = (
                command[5:]
                .strip()
            )

            if note:

                stamp = dt.datetime.now().strftime(
                    "%Y-%m-%d %H:%M"
                )

                with NOTES_FILE.open(
                    "a",
                    encoding="utf-8"
                ) as f:

                    f.write(
                        f"[{stamp}] {note}\n"
                    )

                self.respond(
                    "Note saved."
                )

            return

        # REMEMBER
        if c.startswith(
            "remember that "
        ):

            fact = command[
                len("remember that "):
            ].strip()

            if fact:

                self.memory[
                    "facts"
                ].append(
                    fact
                )

                self.save_memory()

                self.respond(
                    "I will remember that."
                )

            return

        # MEMORY
        if c in {
            "what do you remember",
            "show memory"
        }:

            facts = self.memory.get(
                "facts",
                []
            )

            self.respond(
                "I remember: "
                +
                "; ".join(
                    facts[-5:]
                )
                if facts
                else
                "I don't have any saved memories yet."
            )

            return

        # GESTURE START
        if c in {
            "start gestures",
            "start gesture control",
            "activate gestures",
            "activate gesture control"
        }:

            self.gui.start_gesture_thread()

            self.respond(
                "Gesture control activated."
            )

            return

        # GESTURE STOP
        if c in {
            "stop gestures",
            "stop gesture control",
            "deactivate gestures"
        }:

            self.stop_gesture_control()

            self.respond(
                "Gesture control stopped."
            )

            return

        # HELP
        if c in {
            "help",
            "commands"
        }:

            self.respond(
                "You can ask questions, "
                "open websites, search, "
                "take notes, remember facts, "
                "control the TV, or use hand gestures."
            )

            return

        # AI
        self.ask_ai(
            command
        )

    # ========================================================
    # GESTURE / MOUSE CONTROL
    # ========================================================

    def start_gesture_control(self):
        if self.gesture_running:
            return

        missing = []
        if cv2 is None:
            missing.append("opencv-python")
        if mp is None:
            missing.append("mediapipe")
        if pyautogui is None:
            missing.append("pyautogui")
        if np is None:
            missing.append("numpy")

        if missing:
            self.gui.add_message(
                "SYSTEM",
                "Gesture control needs: " + ", ".join(missing)
            )
            return

        self.gesture_running = True
        self._mouse_left_down = False
        self._last_mouse_xy = None
        self._scroll_anchor_y = None
        self._gesture_candidate = None
        self._gesture_candidate_count = 0
        self._last_action_time = 0.0
        self._last_click_time = 0.0
        self._left_pinch_active = False
        self._right_pinch_active = False

        threading.Thread(
            target=self.gesture_loop,
            daemon=True
        ).start()

    def stop_gesture_control(self):
        self.gesture_running = False

        # Never leave a mouse button held when gesture mode stops.
        if pyautogui is not None:
            try:
                if getattr(self, "_mouse_left_down", False):
                    pyautogui.mouseUp(button="left")
            except Exception:
                pass
        self._mouse_left_down = False
        self._last_mouse_xy = None
        self._scroll_anchor_y = None
        self._left_pinch_active = False
        self._right_pinch_active = False

        if self.camera is not None:
            try:
                self.camera.release()
            except Exception:
                pass
            self.camera = None

        if cv2 is not None:
            try:
                cv2.destroyAllWindows()
            except Exception:
                pass

    def gesture_loop(self):
        self.gui.add_message(
            "SYSTEM",
            "Camera activated. Mouse gesture control ready."
        )

        try:
            self.camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not self.camera.isOpened():
                # Some Windows cameras do not accept CAP_DSHOW.
                try:
                    self.camera.release()
                except Exception:
                    pass
                self.camera = cv2.VideoCapture(0)

            if not self.camera.isOpened():
                self.gui.add_message("SYSTEM", "Could not open camera.")
                self.gesture_running = False
                return

            self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

            while self.gesture_running:
                ret, frame = self.camera.read()
                if not ret:
                    time.sleep(0.01)
                    continue

                frame = cv2.flip(frame, 1)
                self.process_gesture_frame(frame)

                cv2.putText(
                    frame,
                    "PALM = MOVE   PINCH = CLICK   2 FINGERS = SCROLL   ESC = STOP",
                    (10, frame.shape[0] - 15),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.45,
                    (0, 234, 255),
                    1,
                    cv2.LINE_AA,
                )

                cv2.imshow("JARVIS Gesture Control", frame)
                key = cv2.waitKey(1) & 0xFF
                if key == 27:
                    break

        except Exception as e:
            self.gui.add_message("SYSTEM", f"Gesture error: {e}")
        finally:
            self.gesture_running = False
            if pyautogui is not None:
                try:
                    if getattr(self, "_mouse_left_down", False):
                        pyautogui.mouseUp(button="left")
                except Exception:
                    pass
            self._mouse_left_down = False
            self._last_mouse_xy = None
            self._scroll_anchor_y = None
            self._left_pinch_active = False
            self._right_pinch_active = False

            if self.camera is not None:
                try:
                    self.camera.release()
                except Exception:
                    pass
                self.camera = None

            try:
                cv2.destroyWindow("JARVIS Gesture Control")
            except Exception:
                pass

            self.gui.add_message("SYSTEM", "Gesture control stopped.")

    # ========================================================
    # MEDIAPIPE TASKS HAND DETECTOR
    # ========================================================

    def process_gesture_frame(self, frame):
        if mp is None:
            return

        try:
            if not hasattr(self, "_hand_detector"):
                self._hand_detector = self.create_hand_detector()

            detector = self._hand_detector
            if detector is None:
                return

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(
                image_format=mp.ImageFormat.SRGB,
                data=rgb
            )
            result = detector.detect(mp_image)

            if not result.hand_landmarks:
                self._handle_no_hand()
                return

            # Use the first detected hand for the mouse. Two hands can
            # make cursor control unstable, so the nearest/first hand wins.
            landmarks = result.hand_landmarks[0]
            self.handle_hand_landmarks(landmarks, frame)

        except Exception as e:
            now = time.time()
            if now - getattr(self, "_last_gesture_error", 0) > 5:
                self.gui.add_message("SYSTEM", f"Gesture detector: {e}")
                self._last_gesture_error = now

    def _handle_no_hand(self):
        self._gesture_candidate = None
        self._gesture_candidate_count = 0
        self._scroll_anchor_y = None
        # Release a drag if the hand disappears.
        if self._mouse_left_down and pyautogui is not None:
            try:
                pyautogui.mouseUp(button="left")
            except Exception:
                pass
            self._mouse_left_down = False

    def create_hand_detector(self):
        try:
            from mediapipe.tasks import python
            from mediapipe.tasks.python import vision

            model_path = BASE_DIR / "hand_landmarker.task"

            if not model_path.exists():
                self.gui.add_message(
                    "SYSTEM",
                    "Hand model not found. Downloading..."
                )
                model_url = (
                    "https://storage.googleapis.com/mediapipe-models/"
                    "hand_landmarker/hand_landmarker/float16/1/"
                    "hand_landmarker.task"
                )
                try:
                    urlretrieve(model_url, str(model_path))
                except Exception as e:
                    self.gui.add_message(
                        "SYSTEM",
                        f"Could not download hand model: {e}"
                    )
                    return None

            base_options = python.BaseOptions(
                model_asset_path=str(model_path)
            )
            options = vision.HandLandmarkerOptions(
                base_options=base_options,
                running_mode=vision.RunningMode.IMAGE,
                num_hands=1,
                min_hand_detection_confidence=0.55,
                min_hand_presence_confidence=0.55,
                min_tracking_confidence=0.55,
            )
            detector = vision.HandLandmarker.create_from_options(options)
            self.gui.add_message("SYSTEM", "MediaPipe mouse detector initialized.")
            return detector

        except Exception as e:
            self.gui.add_message(
                "SYSTEM",
                f"Hand detector initialization failed: {e}"
            )
            return None

    # ========================================================
    # HAND LANDMARKS + MOUSE
    # ========================================================

    @staticmethod
    def _dist(a, b):
        return math.hypot(a.x - b.x, a.y - b.y)

    def _finger_states(self, lm):
        # Palm-relative finger tests are more stable than checking only
        # absolute screen direction.
        wrist = lm[0]
        index_up = lm[8].y < lm[6].y - 0.015
        middle_up = lm[12].y < lm[10].y - 0.015
        ring_up = lm[16].y < lm[14].y - 0.015
        pinky_up = lm[20].y < lm[18].y - 0.015

        # Thumb extension: compare thumb tip to thumb IP and wrist.
        thumb_extended = self._dist(lm[4], wrist) > self._dist(lm[3], wrist) * 1.08
        return thumb_extended, index_up, middle_up, ring_up, pinky_up

    def _move_cursor(self, hand_landmarks):
        """Move the Windows cursor from the CENTER OF THE PALM, not a fingertip."""
        if pyautogui is None or len(hand_landmarks) < 21:
            return

        try:
            screen_w, screen_h = pyautogui.size()

            # Palm center = wrist + four MCP joints.
            palm_points = [
                hand_landmarks[0],
                hand_landmarks[5],
                hand_landmarks[9],
                hand_landmarks[13],
                hand_landmarks[17],
            ]
            palm_x = sum(p.x for p in palm_points) / len(palm_points)
            palm_y = sum(p.y for p in palm_points) / len(palm_points)

            # Camera control area.
            margin_x = 0.10
            margin_y = 0.10
            x = (palm_x - margin_x) / (1.0 - 2.0 * margin_x)
            y = (palm_y - margin_y) / (1.0 - 2.0 * margin_y)
            x = max(0.0, min(1.0, x))
            y = max(0.0, min(1.0, y))

            target_x = x * (screen_w - 1)
            target_y = y * (screen_h - 1)

            # Low-latency smoothing.
            old = self._last_mouse_xy
            if old is None:
                new_x, new_y = target_x, target_y
            else:
                smooth = 0.78
                new_x = old[0] + (target_x - old[0]) * smooth
                new_y = old[1] + (target_y - old[1]) * smooth

            self._last_mouse_xy = (new_x, new_y)
            mouse_x = int(round(new_x))
            mouse_y = int(round(new_y))

            if getattr(self, "last_mouse_pos", None) != (mouse_x, mouse_y):
                pyautogui.moveTo(mouse_x, mouse_y, duration=0, _pause=False)
                self.last_mouse_pos = (mouse_x, mouse_y)

        except Exception as e:
            now = time.time()
            if now - getattr(self, "_last_mouse_error", 0) > 5:
                self.gui.add_message("SYSTEM", f"Mouse gesture error: {e}")
                self._last_mouse_error = now

    def _left_click(self):
        now = time.time()
        if now - self._last_click_time < 0.45:
            return
        pyautogui.click(button="left")
        self._last_click_time = now

    def _right_click(self):
        now = time.time()
        if now - self._last_click_time < 0.45:
            return
        pyautogui.click(button="right")
        self._last_click_time = now

    def _scroll_from_two_fingers(self, lm):
        # Scroll according to the average vertical movement of index+middle.
        y = (lm[8].y + lm[12].y) / 2.0
        if self._scroll_anchor_y is None:
            self._scroll_anchor_y = y
            return

        delta = self._scroll_anchor_y - y
        if abs(delta) < 0.025:
            return

        amount = int(max(-6, min(6, delta * 70)))
        if amount:
            pyautogui.scroll(amount)
            self._scroll_anchor_y = y

    def _stable_action(self, gesture):
        # Require several identical classifications before an action.
        if gesture == self._gesture_candidate:
            self._gesture_candidate_count += 1
        else:
            self._gesture_candidate = gesture
            self._gesture_candidate_count = 1

        return self._gesture_candidate_count >= 5

    def handle_hand_landmarks(self, landmarks, frame):
        if len(landmarks) < 21 or pyautogui is None:
            return

        thumb_ext, index_up, middle_up, ring_up, pinky_up = self._finger_states(landmarks)
        index_tip = landmarks[8]
        thumb_tip = landmarks[4]
        middle_tip = landmarks[12]

        # Draw a simple hand skeleton/points.
        h, w = frame.shape[:2]
        for lm in landmarks:
            cv2.circle(frame, (int(lm.x * w), int(lm.y * h)), 3, (0, 234, 255), -1)

        # Pinch thresholds are relative to palm size, making them work at
        # different distances from the camera.
        palm = max(self._dist(landmarks[0], landmarks[9]), 0.001)
        index_pinch = self._dist(thumb_tip, index_tip) < palm * 0.42
        middle_pinch = self._dist(thumb_tip, middle_tip) < palm * 0.42

        # Priority: click gestures first, then scroll, then cursor movement.
        # Releasing a pinch arms the next click.
        if not index_pinch:
            self._left_pinch_active = False
        if not middle_pinch:
            self._right_pinch_active = False

        if index_pinch and not middle_pinch:
            self._scroll_anchor_y = None
            gesture = "LEFT CLICK"
            self._move_cursor(landmarks)
            stable = self._stable_action(gesture)
            # Click once when the pinch begins; holding the pinch does not
            # spam clicks. Releasing the pinch arms the next click.
            if stable and not self._left_pinch_active:
                self._left_click()
                self._left_pinch_active = True
            self._right_pinch_active = False

        elif middle_pinch and not index_pinch:
            self._scroll_anchor_y = None
            gesture = "RIGHT CLICK"
            self._move_cursor(landmarks)
            stable = self._stable_action(gesture)
            if stable and not self._right_pinch_active:
                self._right_click()
                self._right_pinch_active = True
            self._left_pinch_active = False

        elif index_up and middle_up and not ring_up and not pinky_up:
            gesture = "SCROLL"
            self._scroll_from_two_fingers(landmarks)
            self._stable_action(gesture)

        elif not index_up and not middle_up and not ring_up and not pinky_up and not thumb_ext:
            self._scroll_anchor_y = None
            gesture = "FIST"
            if self._stable_action(gesture):
                now = time.time()
                if now - self._last_action_time > 1.0:
                    pyautogui.press("volumemute")
                    self._last_action_time = now

        elif thumb_ext and not index_up and not middle_up and not ring_up and not pinky_up:
            # Thumbs up/down are deliberately conservative. A thumb gesture
            # must be held stable and is the only gesture that controls volume.
            self._scroll_anchor_y = None
            thumb_y = thumb_tip.y
            wrist_y = landmarks[0].y
            if thumb_y < wrist_y - 0.08:
                gesture = "THUMBS UP"
                if self._stable_action(gesture):
                    now = time.time()
                    if now - self._last_action_time > 0.6:
                        pyautogui.press("volumeup")
                        self._last_action_time = now
                        self._gesture_candidate_count = 0
            elif thumb_y > wrist_y + 0.08:
                gesture = "THUMBS DOWN"
                if self._stable_action(gesture):
                    now = time.time()
                    if now - self._last_action_time > 0.6:
                        pyautogui.press("volumedown")
                        self._last_action_time = now
                        self._gesture_candidate_count = 0
            else:
                gesture = "READY"
                self._stable_action(gesture)

        elif index_up and middle_up and ring_up and pinky_up:
            self._scroll_anchor_y = None
            gesture = "OPEN PALM"
            if self._stable_action(gesture):
                now = time.time()
                if now - self._last_action_time > 1.0:
                    pyautogui.press("space")
                    self._last_action_time = now
                    self._gesture_candidate_count = 0
        else:
            # --------------------------------------------------------
            # PALM MOUSE
            # --------------------------------------------------------
            # Cursor movement is intentionally independent of the
            # index finger. The palm center is the ONLY movement source.
            self._scroll_anchor_y = None
            gesture = "PALM CURSOR"
            self._stable_action(gesture)
            self._move_cursor(landmarks)

        # Draw the actual palm-center control point so it is obvious
        # what is controlling the Windows cursor.
        palm_points = [
            landmarks[0],
            landmarks[5],
            landmarks[9],
            landmarks[13],
            landmarks[17],
        ]
        palm_x = sum(p.x for p in palm_points) / 5.0
        palm_y = sum(p.y for p in palm_points) / 5.0
        cv2.circle(
            frame,
            (int(palm_x * w), int(palm_y * h)),
            9,
            (0, 255, 120),
            -1
        )
        cv2.circle(
            frame,
            (int(palm_x * w), int(palm_y * h)),
            14,
            (0, 255, 120),
            2
        )
        cv2.putText(
            frame,
            "PALM CONTROL",
            (int(palm_x * w) + 18, int(palm_y * h) - 12),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            (0, 255, 120),
            1,
            cv2.LINE_AA,
        )

        self.draw_gesture_text(frame, gesture)

    def draw_gesture_text(self, frame, gesture):
        cv2.rectangle(frame, (12, 12), (360, 58), (3, 6, 11), -1)
        cv2.putText(
            frame,
            f"GESTURE: {gesture}",
            (25, 43),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.72,
            (0, 234, 255),
            2,
            cv2.LINE_AA,
        )


# ============================================================
# JARVIS GUI
# ============================================================

class JarvisGUI(tk.Tk):

    def __init__(self):

        super().__init__()

        self.title(
            "J.A.R.V.I.S // NEURAL COMMAND"
        )

        self.geometry(
            "1280x800"
        )

        self.minsize(
            1000,
            680
        )

        self.configure(
            bg=BG
        )

        self.engine = JarvisEngine(
            self
        )

        self.build_ui()

        self.animate_core()
        self.update_clock()
        self.update_stats()

        self.add_message(
            "JARVIS",
            "JARVIS online. Neural systems ready."
        )

        self.add_message(
            "SYSTEM",
            f"LOCAL AI // {OLLAMA_MODEL}"
        )

        self.add_message(
            "SYSTEM",
            f"TV TARGET // {TV_IP}:{TV_PORT}"
        )

        self.add_message(
            "SYSTEM",
            "Speaker verification // "
            +
            (
                "ENROLLED"
                if self.engine.voiceprint is not None
                else
                "NOT ENROLLED"
            )
        )

        self.add_message(
            "SYSTEM",
            f"VOICEPRINT FILE // {VOICEPRINT_FILE}"
        )

        # Start wake listener
        threading.Thread(
            target=self.engine.wake_listener,
            daemon=True
        ).start()

    # ========================================================
    # UI
    # ========================================================

    def build_ui(self):
        # ====================================================
        # VIDEO-STYLE JARVIS INTERFACE
        # Blue/cyan boot sequence -> orange neural reactor.
        # The reactor is intentionally the hero element.
        # ====================================================
        self.configure(bg="#020303")
        self.geometry("1440x900")
        self.minsize(1050, 680)
        self._page = "HOME"
        self._boot_active = True
        self._boot_start = time.time()
        self._reactor_phase = 0.0
        self._hud_phase = 0.0

        # ---------- TOP BAR ----------
        top = tk.Frame(self, bg="#020303", height=58)
        top.pack(fill="x", padx=28, pady=(16, 0))
        top.pack_propagate(False)

        tk.Label(top, text="J.A.R.V.I.S", font=("Consolas", 15, "bold"),
                 fg="#ff9a22", bg="#020303").pack(side="left", pady=10)
        tk.Label(top, text="  NEURAL COMMAND SYSTEM", font=("Consolas", 7, "bold"),
                 fg="#654326", bg="#020303").pack(side="left", pady=14)

        self.nav_buttons = {}
        nav = tk.Frame(top, bg="#020303")
        nav.pack(side="right")
        for label in ("HOME", "CHAT", "DASHBOARD"):
            b = tk.Button(nav, text=label, font=("Consolas", 8, "bold"),
                          bg="#020303", fg="#ff9a22" if label == "HOME" else "#59432c",
                          activebackground="#020303", activeforeground="#ffd09a",
                          relief="flat", bd=0, padx=12, pady=7, cursor="hand2",
                          command=lambda p=label: self.switch_page(p))
            b.pack(side="left", padx=2)
            self.nav_buttons[label] = b

        tk.Frame(self, bg="#211407", height=1).pack(fill="x", padx=28)

        # ---------- HOME CANVAS ----------
        self.home_frame = tk.Frame(self, bg="#020303")
        self.home_frame.pack(fill="both", expand=True, padx=0, pady=0)
        self.canvas = tk.Canvas(self.home_frame, bg="#020303", highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)

        self.core_text = self.canvas.create_text(26, 22, anchor="nw", text="CORE // 01",
                                                  fill="#5e4027", font=("Consolas", 7, "bold"))
        self.online_text = self.canvas.create_text(0, 22, anchor="ne", text="● ONLINE",
                                                    fill="#ff9a22", font=("Consolas", 7, "bold"))
        self.left_hud = self.canvas.create_text(28, 0, anchor="sw", justify="left",
                                                text="MIC  STANDBY\nAI   LOCAL / OLLAMA\nAUTH  --",
                                                fill="#67462c", font=("Consolas", 7, "bold"))
        self.right_hud = self.canvas.create_text(0, 0, anchor="se", justify="right",
                                                 text=f"CPU  --\nRAM  --\nTV   {TV_IP}",
                                                 fill="#67462c", font=("Consolas", 7, "bold"))

        # Status is deliberately small; the reactor carries most of the visual feedback.
        self.status_label = tk.Label(self, text="● INITIALIZING", font=("Consolas", 9, "bold"),
                                     fg="#36c8ff", bg="#020303")
        self.status_label.place(relx=0.5, rely=0.78, anchor="center")

        # ---------- BOTTOM COMMAND STRIP ----------
        bottom = tk.Frame(self, bg="#020303", height=112)
        bottom.pack(fill="x", padx=28, pady=(0, 14))
        bottom.pack_propagate(False)

        rail = tk.Frame(bottom, bg="#050505", highlightthickness=1,
                        highlightbackground="#2a1809")
        rail.pack(fill="x", pady=(4, 8))
        tk.Label(rail, text="JARVIS  >", font=("Consolas", 9, "bold"),
                 fg="#ff9a22", bg="#050505").pack(side="left", padx=(12, 5), pady=7)
        self.entry = tk.Entry(rail, bg="#050505", fg="#f8e8d3", insertbackground="#ff9a22",
                              font=("Consolas", 9), relief="flat", bd=0)
        self.entry.pack(side="left", fill="x", expand=True, padx=5, pady=6, ipady=5)
        self.entry.bind("<Return>", self.send_text)
        self.make_button(rail, "SEND", self.send_text, "#ff9a22").pack(side="right", padx=5, pady=4)
        self.make_button(rail, "LISTEN", self.start_manual_listening, "#6ee7a8").pack(side="right", padx=5, pady=4)

        controls = tk.Frame(bottom, bg="#020303")
        controls.pack(fill="x")
        self.make_button(controls, "ENROLL VOICE", self.start_enrollment, "#ffd166").pack(side="left", padx=(0, 5))
        self.make_button(controls, "GESTURES", self.start_gesture_thread, "#6ee7a8").pack(side="left", padx=5)
        self.make_button(controls, "STOP GESTURES", self.stop_gesture, "#ff6255").pack(side="left", padx=5)
        tk.Label(controls, text="AUTO WAKE  //  SAY  JARVIS", font=("Consolas", 7, "bold"),
                 fg="#62452c", bg="#020303").pack(side="right", padx=5)

        # ---------- CHAT PAGE ----------
        self.chat = scrolledtext.ScrolledText(
            self, bg="#030303", fg="#d8b991", insertbackground="#ff9a22",
            font=("Consolas", 9), wrap="word", borderwidth=0,
            highlightthickness=1, highlightbackground="#2a1809", padx=14, pady=14
        )
        self.chat.place_forget()
        self.chat.config(state="disabled")

        # ---------- DASHBOARD PAGE ----------
        self.dashboard = tk.Frame(self, bg="#030303", highlightthickness=1,
                                  highlightbackground="#2a1809")
        self.dashboard.place_forget()
        tk.Label(self.dashboard, text="SYSTEM TELEMETRY", font=("Consolas", 11, "bold"),
                 fg="#ff9a22", bg="#030303").pack(anchor="w", padx=20, pady=(20, 4))
        tk.Label(self.dashboard, text="LOCAL NEURAL CORE / HARDWARE / VOICE",
                 font=("Consolas", 7), fg="#68472d", bg="#030303").pack(anchor="w", padx=20, pady=(0, 14))
        metrics = tk.Frame(self.dashboard, bg="#030303")
        metrics.pack(fill="x", padx=16)
        self.cpu_label = self.hud_label(metrics, "CPU  --")
        self.ram_label = self.hud_label(metrics, "RAM  --")
        self.ai_label = self.hud_label(metrics, f"AI   {OLLAMA_MODEL}")
        self.ai_label.config(fg="#6ee7a8")
        self.mic_label = self.hud_label(metrics, "MIC  WAKE WORD ACTIVE")
        self.mic_label.config(fg="#6ee7a8")
        self.tv_label = self.hud_label(metrics, f"TV   {TV_IP}")
        self.tv_label.config(fg="#69c9ff")
        self.voice_label = self.hud_label(metrics, "VOICE AUTH  " +
                                           ("ENABLED" if self.engine.voiceprint is not None else "NOT ENROLLED"))
        self.voice_label.config(fg="#6ee7a8" if self.engine.voiceprint is not None else "#ffd166")

        tk.Label(self, text="JARVIS // LOCAL AI // VOICE AUTH // ADB // MEDIAPIPE",
                 font=("Consolas", 7), fg="#4e3725", bg="#020303").place(relx=0.02, rely=0.985, anchor="sw")
        tk.Label(self, text="SECURE LOCAL CORE", font=("Consolas", 7, "bold"),
                 fg="#5d422c", bg="#020303").place(relx=0.98, rely=0.985, anchor="se")
        self.clock = tk.Label(self, text="", font=("Consolas", 7), fg="#4e3725", bg="#020303")
        self.clock.place_forget()
        self.switch_page("HOME")

    def _finish_boot(self):
        self._boot_active = False
        self.status_label.config(text="● WAITING", fg="#ff9a22")

    def switch_page(self, page):
        self._page = page

        # Reset navigation colors.
        for name, button in getattr(self, "nav_buttons", {}).items():
            button.config(fg="#ff9a24" if name == page else "#63452c")

        if page == "HOME":
            self.chat.place_forget()
            self.dashboard.place_forget()
            self.home_frame.pack(fill="both", expand=True, padx=28, pady=(8, 0))
            self.status_label.place(relx=0.5, rely=0.80, anchor="center")

        elif page == "CHAT":
            self.home_frame.pack_forget()
            self.dashboard.place_forget()
            self.chat.place(
                relx=0.08, rely=0.14, relwidth=0.84, relheight=0.68
            )
            self.status_label.place(relx=0.5, rely=0.86, anchor="center")

        elif page == "DASHBOARD":
            self.home_frame.pack_forget()
            self.chat.place_forget()
            self.dashboard.place(
                relx=0.16, rely=0.15, relwidth=0.68, relheight=0.67
            )
            self.status_label.place(relx=0.5, rely=0.86, anchor="center")

    # ========================================================
    # GUI HELPERS
    # ========================================================

    def hud_label(
        self,
        parent,
        text
    ):

        label = tk.Label(
            parent,
            text=text,
            font=("Consolas", 9),
            fg=WHITE,
            bg=PANEL2,
            anchor="w"
        )

        label.pack(
            fill="x",
            padx=12,
            pady=5
        )

        return label

    def make_button(
        self,
        parent,
        text,
        command,
        fg
    ):

        return tk.Button(
            parent,
            text=text,
            command=command,
            font=("Consolas", 9, "bold"),
            bg="#0a202b",
            fg=fg,
            activebackground="#123d4e",
            activeforeground=WHITE,
            relief="flat",
            padx=16,
            pady=7,
            cursor="hand2"
        )

    def add_message(
        self,
        sender,
        message
    ):

        def update():

            try:

                self.chat.config(
                    state="normal"
                )

                if sender == "YOU":

                    prefix = (
                        "YOU      > "
                    )

                elif sender == "JARVIS":

                    prefix = (
                        "JARVIS   > "
                    )

                else:

                    prefix = (
                        "SYSTEM   > "
                    )

                tag = (
                    sender
                    if sender in {
                        "YOU",
                        "JARVIS"
                    }
                    else
                    "SYSTEM"
                )

                self.chat.insert(
                    "end",
                    prefix,
                    tag
                )

                self.chat.insert(
                    "end",
                    message +
                    "\n\n"
                )

                self.chat.tag_config(
                    "YOU",
                    foreground=YELLOW,
                    font=(
                        "Consolas",
                        10,
                        "bold"
                    )
                )

                self.chat.tag_config(
                    "JARVIS",
                    foreground=CYAN,
                    font=(
                        "Consolas",
                        10,
                        "bold"
                    )
                )

                self.chat.tag_config(
                    "SYSTEM",
                    foreground=DIM,
                    font=(
                        "Consolas",
                        9,
                        "bold"
                    )
                )

                self.chat.see(
                    "end"
                )

                self.chat.config(
                    state="disabled"
                )

            except Exception:
                pass

        self.after(
            0,
            update
        )

    def send_text(
        self,
        event=None
    ):

        text = (
            self.entry
            .get()
            .strip()
        )

        if not text:
            return

        self.entry.delete(
            0,
            "end"
        )

        threading.Thread(
            target=self.engine.process,
            args=(text,),
            daemon=True
        ).start()

    def set_input(
        self,
        text
    ):

        def update():

            self.entry.delete(
                0,
                "end"
            )

            self.entry.insert(
                0,
                text
            )

        self.after(
            0,
            update
        )

    def start_manual_listening(self):

        threading.Thread(
            target=self.engine.listen_once,
            daemon=True
        ).start()

    def start_enrollment(self):

        threading.Thread(
            target=self.engine.enroll_voice,
            daemon=True
        ).start()

    def start_gesture_thread(self):

        threading.Thread(
            target=self.engine.start_gesture_control,
            daemon=True
        ).start()

    def stop_gesture(self):

        self.engine.stop_gesture_control()

    def voice_auth_update(self):

        def update():

            enrolled = (
                self.engine.voiceprint
                is not None
            )

            self.voice_label.config(
                text=(
                    "VOICE AUTH  "
                    +
                    (
                        "ENABLED"
                        if enrolled
                        else
                        "NOT ENROLLED"
                    )
                ),
                fg=(
                    GREEN
                    if enrolled
                    else
                    YELLOW
                )
            )

        self.after(
            0,
            update
        )

    # ========================================================
    # STATUS
    # ========================================================

    def set_status(
        self,
        status,
        color
    ):

        def update():

            try:

                self.status_label.config(
                    text=f"● {status}",
                    fg=color
                )

                if status == "LISTENING":

                    self.mic_label.config(
                        text="MIC  LISTENING...",
                        fg=YELLOW
                    )

                elif status == "SPEAKING":

                    self.mic_label.config(
                        text="MIC  OUTPUT ACTIVE",
                        fg=GREEN
                    )

                elif status == "THINKING":

                    self.mic_label.config(
                        text="MIC  PROCESSING...",
                        fg=BLUE
                    )

                elif status == "WAKE DETECTED":

                    self.mic_label.config(
                        text="MIC  WAKE VERIFIED",
                        fg=GREEN
                    )

                elif status == "ENROLLING":

                    self.mic_label.config(
                        text="MIC  ENROLLING VOICE",
                        fg=YELLOW
                    )

                elif status == "WAITING":

                    self.mic_label.config(
                        text="MIC  SAY 'JARVIS'",
                        fg=CYAN
                    )

                else:

                    self.mic_label.config(
                        text="MIC  READY",
                        fg=GREEN
                    )

            except Exception:
                pass

        self.after(
            0,
            update
        )

    # ========================================================
    # REACTOR ANIMATION
    # ========================================================

    def animate_core(self):
        try:
            self._reactor_phase += 0.045
            self._hud_phase += 0.03
            if getattr(self, "_page", "HOME") != "HOME":
                self.after(40, self.animate_core)
                return

            self.canvas.delete("reactor")
            w = max(self.canvas.winfo_width(), 760)
            h = max(self.canvas.winfo_height(), 520)
            cx = w * 0.50
            cy = h * 0.44
            t = self._reactor_phase

            self.canvas.coords(self.online_text, w - 26, 22)
            self.canvas.coords(self.left_hud, 28, h - 16)
            self.canvas.coords(self.right_hud, w - 28, h - 16)

            if getattr(self, "_boot_active", False):
                self._draw_boot_screen(cx, cy, w, h, t)
                if time.time() - self._boot_start > 3.2:
                    self._finish_boot()
            else:
                self._draw_orange_reactor(cx, cy, w, h, t)

            self.after(33, self.animate_core)
        except Exception:
            self.after(100, self.animate_core)

    def _draw_boot_screen(self, cx, cy, w, h, t):
        # Cyan boot animation: intentionally temporary, matching the reference flow.
        cyan = "#25c9ff"
        dim = "#0b5d78"
        faint = "#063044"
        pulse = (math.sin(t * 3.2) + 1) * 0.5
        R = min(w, h) * 0.18

        self.canvas.itemconfig(self.online_text, text="● BOOTING", fill=cyan)
        self.canvas.itemconfig(self.left_hud, text="CORE  INITIALIZING\nMIC   CALIBRATING\nAI    LOADING", fill=dim)
        self.canvas.itemconfig(self.right_hud, text="NEURAL  01\nVOICE   CHECK\nSYSTEM  BOOT", fill=dim)

        # Scan lines.
        scan_y = (cy - R * 1.9) + ((t * 170) % (R * 3.8))
        self.canvas.create_line(cx - R * 2.4, scan_y, cx + R * 2.4, scan_y,
                                fill=dim, width=1, tags="reactor")
        for k in range(7):
            rr = R * (0.55 + k * 0.18)
            self.canvas.create_oval(cx-rr, cy-rr*0.58, cx+rr, cy+rr*0.58,
                                    outline=faint if k > 2 else dim, width=1, tags="reactor")

        # Boot reactor: geometric cyan sphere.
        for i in range(12):
            a = t * (0.35 + i * 0.005) + i * math.pi / 12
            sx = abs(math.cos(a))
            rx = R * max(0.025, sx)
            self.canvas.create_oval(cx-rx, cy-R, cx+rx, cy+R,
                                    outline=dim if i % 2 else cyan, width=1, tags="reactor")
        for lat in (-0.72, -0.42, -0.18, 0, 0.18, 0.42, 0.72):
            yy = cy - lat * R
            rx = R * math.sqrt(max(0.04, 1-lat*lat))
            self.canvas.create_oval(cx-rx, yy-R*0.12, cx+rx, yy+R*0.12,
                                    outline=dim, width=1, tags="reactor")

        for i in range(26):
            a = t * (0.22 + (i % 3) * 0.04) + i * 2.41
            rr = R * (1.05 + (i % 7) * 0.09)
            x = cx + math.cos(a) * rr
            y = cy + math.sin(a) * rr * 0.62
            self.canvas.create_oval(x-1, y-1, x+1, y+1, fill=cyan if i % 4 == 0 else dim,
                                    outline="", tags="reactor")

        self.canvas.create_text(cx, cy-R*1.55, text="J.A.R.V.I.S",
                                fill=cyan, font=("Consolas", 18, "bold"), tags="reactor")
        self.canvas.create_text(cx, cy-R*1.25, text="INITIALIZING NEURAL COMMAND CORE",
                                fill=dim, font=("Consolas", 7, "bold"), tags="reactor")
        bars = 18
        active = int(((t * 2.8) % bars) + 1)
        yb = cy + R * 1.45
        for i in range(bars):
            x = cx - bars*5 + i*10
            self.canvas.create_rectangle(x, yb, x+6, yb+3,
                                          fill=cyan if i < active else faint, outline="", tags="reactor")

    def _draw_orange_reactor(self, cx, cy, w, h, t):
        # Main reference-inspired orange energy sphere.
        orange = "#ff8a16"
        hot = "#ffc05a"
        gold = "#ffb52f"
        dim = "#8d3d0b"
        faint = "#351707"
        pulse = (math.sin(t * 2.4) + 1.0) * 0.5
        R = min(w, h) * 0.205
        R *= 0.97 + pulse * 0.025

        self.canvas.itemconfig(self.online_text, text="● ONLINE", fill=orange)
        self.canvas.itemconfig(self.left_hud, fill="#6a4527")
        self.canvas.itemconfig(self.right_hud, fill="#6a4527")

        # Ambient dust field.
        for i in range(115):
            a = i * 2.399 + t * (0.06 + (i % 5) * 0.006)
            rr = R * (1.18 + (i % 19) * 0.055)
            x = cx + math.cos(a) * rr * (1.05 + 0.04*math.sin(i))
            y = cy + math.sin(a) * rr * 0.66
            s = 1 if i % 7 else 2
            self.canvas.create_oval(x-s, y-s, x+s, y+s,
                                    fill=hot if i % 13 == 0 else dim,
                                    outline="", tags="reactor")

        # Outer orbital tracks.
        for j, (rr, sy, speed) in enumerate(((R*1.12,.24,.55),(R*1.28,.38,-.42),(R*1.47,.16,.29))):
            pts=[]
            ang=t*speed + j*0.8
            for n in range(101):
                q=n*2*math.pi/100
                x=rr*math.cos(q)
                y=rr*math.sin(q)*sy
                xr=x*math.cos(ang)-y*math.sin(ang)
                yr=x*math.sin(ang)+y*math.cos(ang)
                pts += [cx+xr, cy+yr]
            self.canvas.create_line(*pts, fill=orange if j==0 else dim,
                                    width=2 if j==0 else 1, smooth=True, tags="reactor")

        # Tangled 3D wireframe sphere.
        for i in range(15):
            a = t*0.34 + i*math.pi/15
            squeeze = abs(math.cos(a))
            rx = R * max(0.025, squeeze)
            self.canvas.create_oval(cx-rx, cy-R, cx+rx, cy+R,
                                    outline=gold if i in (2,7,12) else dim,
                                    width=2 if i in (2,7,12) else 1, tags="reactor")
        for lat in (-.82,-.64,-.43,-.20,0,.20,.43,.64,.82):
            yy=cy-lat*R
            rx=R*math.sqrt(max(.025,1-lat*lat))
            ry=R*(.055+.02*(1-abs(lat)))
            self.canvas.create_oval(cx-rx,yy-ry,cx+rx,yy+ry,
                                    outline=gold if abs(lat)<.3 else dim,
                                    width=1, tags="reactor")

        # High-energy diagonal filaments, the key visual from the reference.
        for i in range(42):
            a = t*(0.12 + (i%4)*0.018) + i*math.pi/21
            rr1 = R*(0.15+(i%5)*0.11)
            rr2 = R*(0.95+(i%7)*0.06)
            x1=cx+math.cos(a)*rr1; y1=cy+math.sin(a)*rr1
            x2=cx+math.cos(a+0.55*math.sin(t+i))*rr2
            y2=cy+math.sin(a+0.55*math.sin(t+i))*rr2*0.88
            self.canvas.create_line(x1,y1,x2,y2,
                                    fill=hot if i%11==0 else dim,
                                    width=2 if i%13==0 else 1,
                                    tags="reactor")

        # Three sweeping bright arcs around the sphere.
        for j in range(3):
            pts=[]
            phase=t*(0.42+j*.09)+j*2.1
            for n in range(61):
                q=-1.15+n*2.3/60
                x=(R*1.05)*math.cos(q)
                y=(R*(0.30+0.08*j))*math.sin(q)
                xr=x*math.cos(phase)-y*math.sin(phase)
                yr=x*math.sin(phase)+y*math.cos(phase)
                pts += [cx+xr,cy+yr]
            self.canvas.create_line(*pts, fill=hot if j==0 else gold,
                                    width=3 if j==0 else 2, smooth=True, tags="reactor")

        # Bright central energy core.
        for k in range(10,0,-1):
            rr=R*(.16*k/10)+4
            self.canvas.create_oval(cx-rr,cy-rr,cx+rr,cy+rr,
                                    outline="#6c2c06" if k>4 else orange,
                                    fill="#080301" if k>3 else "#2a0d02",
                                    width=1, tags="reactor")
        cr=R*(.075+.012*pulse)
        self.canvas.create_oval(cx-cr*2.3,cy-cr*2.3,cx+cr*2.3,cy+cr*2.3,
                                outline=gold,width=2,tags="reactor")
        self.canvas.create_oval(cx-cr,cy-cr,cx+cr,cy+cr,
                                fill=orange,outline=hot,width=1,tags="reactor")
        self.canvas.create_oval(cx-cr*.38,cy-cr*.38,cx+cr*.38,cy+cr*.38,
                                fill="#fff0c5",outline="",tags="reactor")

        # Technical markers and title.
        for side in (-1,1):
            x0=cx+side*R*1.55
            self.canvas.create_line(x0-side*40,cy,x0,cy,fill=faint,width=1,tags="reactor")
            self.canvas.create_text(x0+side*10,cy-12,anchor="w" if side>0 else "e",
                                    text="07" if side>0 else "01",fill=dim,
                                    font=("Consolas",7,"bold"),tags="reactor")
        self.canvas.create_text(cx,cy+R*1.62,text="J A R V I S",
                                fill=orange,font=("Consolas",13,"bold"),tags="reactor")
        self.canvas.create_text(cx,cy+R*1.76,text="NEURAL CORE  //  ACTIVE",
                                fill="#6d4728",font=("Consolas",7,"bold"),tags="reactor")

        # Tiny status waveform under reactor.
        wave_y=cy+R*1.91
        pts=[]
        for i in range(70):
            xx=cx-R*1.15+i*(R*2.3/69)
            amp=(2.5+8*(1 if i%9 in (0,1) else .18))*(.7+.3*pulse)
            yy=wave_y+math.sin(i*.75+t*5)*amp
            pts += [xx,yy]
        self.canvas.create_line(*pts,fill=dim,width=1,smooth=True,tags="reactor")

    # ========================================================
    # CLOCK
    # ========================================================

    def update_clock(self):

        try:

            self.clock.config(
                text=dt.datetime.now().strftime(
                    "%d %B %Y   //   %H:%M:%S"
                )
            )

        except Exception:
            pass

        self.after(
            1000,
            self.update_clock
        )

    # ========================================================
    # CPU / RAM
    # ========================================================

    def update_stats(self):

        if psutil:

            try:

                self.cpu_label.config(
                    text=(
                        f"CPU  "
                        f"{psutil.cpu_percent(interval=None):>5.1f}%"
                    )
                )

                ram = psutil.virtual_memory().percent
                cpu = psutil.cpu_percent(interval=None)
                self.ram_label.config(text=f"RAM  {ram:>5.1f}%")
                self.cpu_label.config(text=f"CPU  {cpu:>5.1f}%")
                if hasattr(self, "right_hud"):
                    self.canvas.itemconfig(
                        self.right_hud,
                        text=f"CPU  {cpu:>5.1f}%\nRAM  {ram:>5.1f}%\nTV   {TV_IP}"
                    )

            except Exception:
                pass

        self.after(
            3000,
            self.update_stats
        )

    # ========================================================
    # SAFE CLOSE
    # ========================================================

    def on_close(self):

        try:

            self.engine.running = False

            self.engine.stop_gesture_control()

        except Exception:
            pass

        self.destroy()


# ============================================================
# START JARVIS
# ============================================================

if __name__ == "__main__":

    try:

        app = JarvisGUI()

        app.protocol(
            "WM_DELETE_WINDOW",
            app.on_close
        )

        app.mainloop()

    except Exception as e:

        print(
            "JARVIS STARTUP ERROR:",
            e
        )

        try:

            messagebox.showerror(
                "JARVIS Error",
                str(e)
            )

        except Exception:
            pass