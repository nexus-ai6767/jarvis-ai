@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS
color 0A

cls
echo ============================================================
echo                    J A R V I S
 echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python is missing. Run install.bat first.
    echo.
    pause
    exit /b 1
)

where ollama >nul 2>nul
if errorlevel 1 (
    echo Ollama is missing. Run install.bat first.
    echo.
    pause
    exit /b 1
)

ollama list | findstr /I "qwen2.5:1.5b" >nul 2>nul
if errorlevel 1 (
    echo qwen2.5:1.5b is not installed yet.
    echo Run install.bat first.
    echo.
    pause
    exit /b 1
)

echo Starting JARVIS...
echo Close this window only after JARVIS exits.
echo.
py main.py
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" (
    echo.
    echo ============================================================
    echo JARVIS stopped with an error. Error code: %ERR%
    echo ============================================================
    echo.
    echo Tip: run check_setup.bat and follow its instructions.
    echo.
    pause
)
exit /b %ERR%
