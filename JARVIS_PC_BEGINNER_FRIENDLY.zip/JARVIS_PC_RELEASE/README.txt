JARVIS PC - BEGINNER FRIENDLY EDITION
======================================

A local JARVIS-style desktop AI assistant for Windows.

WHAT YOU GET
------------
- Local Ollama AI using qwen2.5:1.5b
- Voice wake word and speech commands
- pyttsx3 voice output
- Local voice enrollment / verification
- Persistent memory and notes
- Windows application and website launching
- TV control through ADB
- MediaPipe + OpenCV hand gesture mouse control
- CPU / RAM monitoring

BEFORE YOU START
----------------
You need:
1. Windows 10/11
2. Python 3.11.x is recommended
3. Ollama installed
4. A working microphone + speakers for voice features
5. A webcam only if you want gesture control

FIRST-TIME SETUP (EASIEST METHOD)
---------------------------------
1. Extract this ZIP anywhere, such as your Desktop.
2. Double-click install.bat.
3. Follow the messages on screen.
4. When setup says READY, double-click start_jarvis.bat.

The installer checks Python and Ollama, installs the Python packages,
and downloads qwen2.5:1.5b if it is missing.

IF SOMETHING DOESN'T WORK
-------------------------
Double-click check_setup.bat.
It will show which component is missing.
Then run install.bat again after fixing the indicated item.

IMPORTANT PRIVACY / NETWORK NOTE
--------------------------------
The AI model runs locally through Ollama. Installing JARVIS on another
PC does not automatically give that PC access to this PC.

TV CONTROL
----------
TV control requires the TV ADB connection configured in main.py.
The current release contains a TV IP setting; change it only if you
want to control your own compatible TV on your own network.

VOICEPRINT
----------
The voiceprint is a convenience speaker-matching feature, not strong
biometric security.

TROUBLESHOOTING
---------------
- Python missing: install Python 3.11.x and enable PATH.
- Ollama missing: install Ollama and start the Ollama app.
- AI model missing: run install.bat again.
- Microphone problems: check Windows microphone permissions and the
  MIC_DEVICE setting in main.py.
- Gesture problems: check webcam permissions and try check_setup.bat.
