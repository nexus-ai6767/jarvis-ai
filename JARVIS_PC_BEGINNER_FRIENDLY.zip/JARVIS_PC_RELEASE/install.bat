@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS - First Time Setup
color 0A

cls
echo ============================================================
echo                 J A R V I S   P C
echo                  FIRST TIME SETUP
 echo ============================================================
echo.
echo This setup will check your PC, install Python packages,
echo and prepare the local AI model used by JARVIS.
echo.
echo Nothing here connects your PC to another person's PC.
echo.

where py >nul 2>nul
if errorlevel 1 goto NO_PYTHON

for /f "tokens=*" %%V in ('py --version 2^>^&1') do set "PYVER=%%V"
echo [1/4] Python detected: %PYVER%

echo.
echo [2/4] Upgrading pip...
py -m pip install --upgrade pip
if errorlevel 1 goto PIP_FAIL

echo.
echo [3/4] Installing JARVIS Python packages...
py -m pip install -r requirements.txt
if errorlevel 1 goto PKG_FAIL

echo.
echo [4/4] Checking Ollama...
where ollama >nul 2>nul
if errorlevel 1 goto NO_OLLAMA

echo Ollama command found.
echo Checking for qwen2.5:1.5b...
ollama list | findstr /I "qwen2.5:1.5b" >nul 2>nul
if errorlevel 1 (
    echo Model not found. Downloading qwen2.5:1.5b now...
    echo This can take a few minutes depending on your internet speed.
    ollama pull qwen2.5:1.5b
    if errorlevel 1 goto MODEL_FAIL
) else (
    echo qwen2.5:1.5b is already installed.
)

echo.
echo ============================================================
echo                 SETUP COMPLETE - READY
 echo ============================================================
echo.
echo You can now double-click start_jarvis.bat
 echo.
pause
exit /b 0

:NO_PYTHON
cls
echo ============================================================
echo PYTHON WAS NOT FOUND
 echo ============================================================
echo.
echo JARVIS needs Python installed on this PC.
echo.
echo Recommended: Python 3.11.x
 echo.
echo Install Python from python.org and enable:
echo     Add python.exe to PATH
 echo.
echo Then run this file again.
echo.
pause
exit /b 1

:PIP_FAIL
echo.
echo ERROR: pip could not be upgraded.
echo Check your internet connection and try again.
pause
exit /b 1

:PKG_FAIL
echo.
echo ERROR: Some Python packages could not be installed.
echo If the error mentions MediaPipe, use Python 3.11.x and retry.
pause
exit /b 1

:NO_OLLAMA
cls
echo ============================================================
echo OLLAMA WAS NOT FOUND
 echo ============================================================
echo.
echo JARVIS uses Ollama for its local AI brain.
echo.
echo 1. Install Ollama from ollama.com
 echo 2. Start the Ollama app
 echo 3. Run this setup file again
 echo.
pause
exit /b 1

:MODEL_FAIL
echo.
echo ERROR: qwen2.5:1.5b could not be downloaded.
echo Make sure Ollama is running and your internet is available.
pause
exit /b 1
