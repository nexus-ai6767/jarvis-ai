@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title JARVIS - Setup Checker
color 0B

cls
echo ============================================================
echo              JARVIS - SETUP CHECKER
 echo ============================================================
echo.

set "OK=1"

echo [Python]
where py >nul 2>nul
if errorlevel 1 (
    echo   [X] Python launcher not found
    set "OK=0"
) else (
    for /f "tokens=*" %%V in ('py --version 2^>^&1') do echo   [OK] %%V
)

echo.
echo [Python packages]
if exist requirements.txt (
    py -m pip show speechrecognition >nul 2>nul && echo   [OK] SpeechRecognition || (echo   [X] SpeechRecognition missing & set "OK=0")
    py -m pip show pyttsx3 >nul 2>nul && echo   [OK] pyttsx3 || (echo   [X] pyttsx3 missing & set "OK=0")
    py -m pip show sounddevice >nul 2>nul && echo   [OK] sounddevice || (echo   [X] sounddevice missing & set "OK=0")
    py -m pip show numpy >nul 2>nul && echo   [OK] numpy || (echo   [X] numpy missing & set "OK=0")
    py -m pip show psutil >nul 2>nul && echo   [OK] psutil || (echo   [X] psutil missing & set "OK=0")
    py -m pip show opencv-python >nul 2>nul && echo   [OK] OpenCV || (echo   [X] OpenCV missing & set "OK=0")
    py -m pip show mediapipe >nul 2>nul && echo   [OK] MediaPipe || (echo   [X] MediaPipe missing & set "OK=0")
    py -m pip show pyautogui >nul 2>nul && echo   [OK] PyAutoGUI || (echo   [X] PyAutoGUI missing & set "OK=0")
)

echo.
echo [Ollama]
where ollama >nul 2>nul
if errorlevel 1 (
    echo   [X] Ollama not found
    set "OK=0"
) else (
    echo   [OK] Ollama command found
    ollama list | findstr /I "qwen2.5:1.5b" >nul 2>nul
    if errorlevel 1 (
        echo   [X] qwen2.5:1.5b not installed
        set "OK=0"
    ) else echo   [OK] qwen2.5:1.5b installed
)

echo.
echo [Files]
for %%F in (main.py requirements.txt install.bat start_jarvis.bat) do (
    if exist "%%F" (echo   [OK] %%F) else (echo   [X] %%F missing & set "OK=0")
)

echo.
if "%OK%"=="1" (
    echo ============================================================
    echo EVERYTHING LOOKS READY. You can run start_jarvis.bat
    echo ============================================================
) else (
    echo ============================================================
    echo SETUP IS INCOMPLETE. Run install.bat to fix missing items.
    echo ============================================================
)
echo.
pause
